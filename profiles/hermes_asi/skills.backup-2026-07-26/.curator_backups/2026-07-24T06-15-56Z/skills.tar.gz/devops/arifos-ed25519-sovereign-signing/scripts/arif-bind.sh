#!/usr/bin/env bash
# One-shot sovereign session bind. Generates fresh nonce, signs with PEM key,
# calls arif_init delegate directly. Returns actor_verified=true on success.
set -euo pipefail
cd /opt/arifos/app
python3 /root/.hermes/scripts/arif-bind.py --mode "$@"
