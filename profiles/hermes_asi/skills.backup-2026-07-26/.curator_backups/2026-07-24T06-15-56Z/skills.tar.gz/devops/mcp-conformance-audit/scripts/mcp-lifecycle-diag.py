#!/usr/bin/env python3
"""MCP Streamable HTTP lifecycle diagnostic.

Template — copy and modify MCP_BASE for your server.

Performs: health → initialize → notifications/initialized →
tools/list → resources/list → prompts/list

Captures ALL response details: HTTP status, Content-Type,
body mode (json/sse), protocol version, server name/version,
session_id, capabilities.

Handles BOTH application/json and text/event-stream response types.
"""
import json
import sys
import time
import urllib.request
import urllib.error

MCP_BASE = "http://localhost:8081/mcp"
HEALTH_URL = MCP_BASE.replace("/mcp", "/health")
OUTPUT_PATH = "artifacts/conformance/initialize-capture.json"
HEADERS_JSON = {"Content-Type": "application/json", "Accept": "application/json"}
HEADERS_SSE  = {"Content-Type": "application/json", "Accept": "text/event-stream"}


def mcp_post(endpoint: str, payload: dict, headers: dict, session_id: str | None = None, timeout: int = 15):
    """POST to MCP endpoint, returning full response details."""
    url = f"{MCP_BASE}{endpoint}"
    data = json.dumps(payload).encode("utf-8")
    req_headers = dict(headers)
    if session_id:
        req_headers["mcp-session-id"] = session_id  # NOTE: lowercase in FastMCP

    req = urllib.request.Request(url, data=data, headers=req_headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw_body = resp.read()
            status = resp.status
            resp_headers = {k.lower(): v for k, v in resp.headers.items()}
    except urllib.error.HTTPError as e:
        raw_body = e.read()
        status = e.code
        resp_headers = {k.lower(): v for k, v in e.headers.items()}
    except Exception as e:
        return {"endpoint": endpoint, "error": str(e), "status": None}

    content_type = resp_headers.get("content-type", "")
    if "text/event-stream" in content_type:
        body_mode = "sse"
        parsed = _parse_sse(raw_body)
    elif "application/json" in content_type:
        body_mode = "json"
        try:
            parsed = json.loads(raw_body.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            parsed = {"_raw": raw_body.decode("utf-8", errors="replace")}
    else:
        body_mode = "unknown"
        try:
            parsed = raw_body.decode("utf-8")
        except UnicodeDecodeError:
            parsed = f"<binary {len(raw_body)} bytes>"

    new_session_id = resp_headers.get("mcp-session-id", None)

    return {
        "endpoint": endpoint, "status": status, "content_type": content_type,
        "body_mode": body_mode, "session_id": new_session_id or session_id,
        "body": parsed, "body_size": len(raw_body),
    }


def _parse_sse(raw: bytes) -> dict:
    text = raw.decode("utf-8", errors="replace")
    events = []
    current_event = {}
    for line in text.split("\n"):
        line = line.rstrip("\r")
        if not line:
            if current_event:
                events.append(current_event)
                current_event = {}
            continue
        if line.startswith("data:"):
            current_event.setdefault("data", []).append(line[5:].strip())
    if current_event:
        events.append(current_event)
    return {"events": events, "event_count": len(events)}


def main():
    results = []

    # Step: Health
    try:
        with urllib.request.urlopen(HEALTH_URL, timeout=10) as resp:
            h = json.loads(resp.read())
        results.append({"step": "health", "status": h.get("status"), "version": h.get("version")})
    except Exception as e:
        results.append({"step": "health", "error": str(e)})

    # Step: Initialize
    init_payload = {
        "jsonrpc": "2.0", "id": 1, "method": "initialize",
        "params": {
            "protocolVersion": "2025-03-26",
            "capabilities": {"tools": {}, "resources": {}, "prompts": {}, "logging": {}, "experimental": {}},
            "clientInfo": {"name": "conformance-test", "version": "0.1.0"},
        },
    }
    r = mcp_post("", init_payload, HEADERS_JSON)
    session_id = r.get("session_id")
    body = r.get("body", {})
    if isinstance(body, dict):
        result = body.get("result", {})
        r["protocol_version"] = result.get("protocolVersion")
        r["server_info"] = result.get("serverInfo")
        r["capabilities"] = result.get("capabilities")
    results.append({"step": "initialize_json", **r})

    if not session_id:
        results.append({"step": "_error", "message": "No session ID — aborting"})
        write_output(results)
        return

    # Step: notifications/initialized
    r = mcp_post("", {"jsonrpc": "2.0", "method": "notifications/initialized"}, HEADERS_JSON, session_id=session_id)
    results.append({"step": "notifications_initialized", **r})

    # Step: tools/list
    r = mcp_post("", {"jsonrpc": "2.0", "id": 2, "method": "tools/list"}, HEADERS_JSON, session_id=session_id)
    body = r.get("body", {})
    if isinstance(body, dict):
        tools_list = body.get("result", {}).get("tools", [])
        r["tool_count"] = len(tools_list)
        r["tool_names"] = [t.get("name") for t in tools_list]
    results.append({"step": "tools_list", **r})

    # Step: resources/list
    r = mcp_post("", {"jsonrpc": "2.0", "id": 3, "method": "resources/list"}, HEADERS_JSON, session_id=session_id)
    body = r.get("body", {})
    if isinstance(body, dict):
        resources = body.get("result", {}).get("resources", [])
        r["resource_count"] = len(resources)
        r["resource_uris"] = [res.get("uri") for res in resources[:50]]
        ui_uris = [u for u in r["resource_uris"] if u.startswith("ui://")]
        r["ui_resource_count"] = len(ui_uris)
    results.append({"step": "resources_list", **r})

    # Step: prompts/list
    r = mcp_post("", {"jsonrpc": "2.0", "id": 4, "method": "prompts/list"}, HEADERS_JSON, session_id=session_id)
    body = r.get("body", {})
    if isinstance(body, dict):
        r["prompt_count"] = len(body.get("result", {}).get("prompts", []))
    results.append({"step": "prompts_list", **r})

    # Step: SSE rejection test
    r = mcp_post("", init_payload, HEADERS_SSE)
    results.append({"step": "initialize_sse", **r})

    # Summary
    summary = {
        "captured_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "mcp_base": MCP_BASE,
        "session_id": session_id,
        "tool_count": results[3].get("tool_count") if len(results) > 3 else None,
        "resource_count": results[4].get("resource_count") if len(results) > 4 else None,
        "ui_resource_count": results[4].get("ui_resource_count") if len(results) > 4 else None,
        "prompt_count": results[5].get("prompt_count") if len(results) > 5 else None,
        "protocol_version": results[1].get("protocol_version") if len(results) > 1 else None,
        "verdict": "PASS" if (
            results[3].get("tool_count", 0) >= 16 and
            results[1].get("protocol_version") == "2025-03-26"
        ) else "NEEDS_INVESTIGATION",
    }
    results.append({"step": "_summary", **summary})
    write_output(results)


def write_output(results):
    import os
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"Saved {len(results)} steps to {OUTPUT_PATH}")
    s = results[-1]
    print(f"  Verdict: {s.get('verdict')}, Tools: {s.get('tool_count')}, Resources: {s.get('resource_count')}, Prompts: {s.get('prompt_count')}")


if __name__ == "__main__":
    main()
