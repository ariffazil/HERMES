#!/usr/bin/env bash
# categorize_upstream_commits.sh — Categorize commits between local and upstream
# Usage: ./categorize_upstream_commits.sh [upstream_ref] [local_ref]
# Defaults: upstream_ref=origin/main, local_ref=HEAD

set -euo pipefail

UPSTREAM="${1:-origin/main}"
LOCAL="${2:-HEAD}"

echo "=== DRIFT SUMMARY ==="
echo -n "Commits ahead (local): " && git log --oneline "$UPSTREAM".."$LOCAL" 2>/dev/null | wc -l
echo -n "Commits behind (upstream): " && git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | wc -l
echo ""

echo "=== LOCAL COMMITS ==="
git log --oneline "$UPSTREAM".."$LOCAL" 2>/dev/null || echo "(none)"
echo ""

echo "=== CATEGORY COUNTS ==="
echo -n "fix: " && git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | grep -c "^[a-f0-9]* fix" || echo 0
echo -n "feat: " && git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | grep -c "^[a-f0-9]* feat" || echo 0
echo -n "refactor: " && git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | grep -c "^[a-f0-9]* refactor" || echo 0
echo -n "perf: " && git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | grep -c "^[a-f0-9]* perf" || echo 0
echo -n "test: " && git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | grep -c "^[a-f0-9]* test" || echo 0
echo -n "chore: " && git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | grep -c "^[a-f0-9]* chore" || echo 0
echo ""

echo "=== SECURITY PATCHES ==="
git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | grep -iE "security|vuln|CVE|exploit|inject|auth.*bypass|token.*leak|credential.*expos|permission.*escalat" || echo "(none)"
echo ""

echo "=== CRITICAL FIXES ==="
git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | grep -iE "fix.*critical|hotfix|breaking|regression|crash|data.*loss|corrupt|deadlock|hang|wedged|bricked" || echo "(none)"
echo ""

echo "=== FEATURES ==="
git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | grep "^[a-f0-9]* feat" | head -20 || echo "(none)"
echo ""

echo "=== HIGH-INTEREST FIXES ==="
git log --oneline "$LOCAL".."$UPSTREAM" 2>/dev/null | grep -iE "fix.*(agent|gateway|config|provider|memory|cron|model|tool|mcp|session|auth|security)" | head -20 || echo "(none)"
echo ""

echo "=== FILE-LEVEL DELTA ==="
git diff --stat "$UPSTREAM".."$LOCAL" 2>/dev/null | tail -5
