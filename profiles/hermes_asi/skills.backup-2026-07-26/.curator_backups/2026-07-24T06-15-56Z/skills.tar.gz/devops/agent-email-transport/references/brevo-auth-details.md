# Brevo authentication

Brevo credentials must be resolved from `/root/.secrets/vault.env` at runtime.
Never copy credential values or prefixes into this repository, examples, logs, or
generated artifacts.

Required environment variables:

- `BREVO_API_KEY`
- `BREVO_SENDER_EMAIL`
- `BREVO_SENDER_NAME`

Before use, verify only that the variables are present. Do not print their values.
