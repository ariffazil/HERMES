#!/usr/bin/env python3
import sys
import argparse
import subprocess
import json

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True)
    parser.add_argument("--prompt", required=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    cmd = [
        "mmx", "vision", "describe",
        "--image", args.image,
        "--prompt", args.prompt,
        "--output", "json",
        "--quiet",
        "--non-interactive"
    ]

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(res.stdout)
        print(json.dumps({"content": data.get("content", "")}))
    except subprocess.CalledProcessError as e:
        sys.stderr.write(e.stderr or e.stdout or str(e))
        sys.exit(e.returncode or 1)
    except Exception as e:
        sys.stderr.write(str(e))
        sys.exit(1)

if __name__ == "__main__":
    main()
