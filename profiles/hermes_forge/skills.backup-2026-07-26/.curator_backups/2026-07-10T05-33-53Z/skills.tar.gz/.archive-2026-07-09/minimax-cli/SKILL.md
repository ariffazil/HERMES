---
name: minimax-cli
description: "MiniMax multimodal via mmx-cli — TTS, video, music, image, vision, search"
version: 1.0.0
tags: [minimax, tts, video, music, image, vision, multimodal]
metadata:
  hermes:
    requires: [mmx-cli]
---

# MiniMax CLI (mmx-cli)

MiniMax multimodal capabilities via `mmx` CLI. Token Plan subscription required.

## Prerequisites

- `npm install -g mmx-cli`
- `mmx auth login --api-key <sk-cp-key>`
- Region auto-detected from key (global/cn)

## Commands

| Capability | Command | Example |
|---|---|---|
| Text chat | `mmx text chat --message "..."` | `mmx text chat --message "Explain NPV"` |
| TTS | `mmx speech synthesize --text "..." --out voice.mp3` | `mmx speech synthesize --text "Hello" --out hi.mp3` |
| Image gen | `mmx image generate --prompt "..."` | `mmx image generate --prompt "sunset ocean" --aspect-ratio 16:9` |
| Video gen | `mmx video generate --prompt "..."` | `mmx video generate --prompt "cat at sunset"` |
| Music gen | `mmx music generate --prompt "..."` | `mmx music generate --prompt "jazz summer" --out jazz.mp3` |
| Vision | `mmx vision describe --file image.png` | `mmx vision describe --file photo.jpg` |
| Web search | `mmx search query --query "..."` | `mmx search query --query "oil price today"` |
| Quota | `mmx quota` | Check remaining Token Plan balance |
| Auth status | `mmx auth status` | Verify login + region |

## Global flags

- `--api-key <key>` — override auth
- `--region global|cn` — force region
- `--output json|text` — output format
- `--timeout <seconds>` — request timeout (default 300)
- `--non-interactive` — CI/agent mode (no prompts)

## Output

Files saved to `minimax-output/` in cwd. When using from Hermes, display media directly in output.

## Quota

- Monthly Max: ~5.1B M3 tokens, 3 video/day,21 video/week
- General models + video + speech + music + image share one quota bar
- 5-hour rolling window + weekly window
- TTS free for limited time (doesn't consume quota)

## TTS Fallback Chain (Telegram voice messages)

When Arif requests voice messages (TTS), use this fallback order:

1. **Built-in `text_to_speech` tool** — uses OpenAI by default, fast, good quality. Fails on quota (429).
2. **`edge-tts` CLI** — free, no API key, good Malay voice. Install: `pip install edge-tts --break-system-packages`
   ```bash
   # Malay male voice
   edge-tts --text "your text" --voice ms-MY-OsmanNeural --write-media /tmp/tts_output.mp3
   # Malay female voice
   edge-tts --text "your text" --voice ms-MY-YasminNeural --write-media /tmp/tts_output.mp3
   ```
   Send with `MEDIA:/tmp/tts_output.mp3` in response.
3. **`mmx speech synthesize`** — MiniMax TTS, quota-based but high quality.

**When user says "voice" or "TTS":** try built-in first → if 429 → fall back to edge-tts immediately (no need to ask).

## Pitfalls

- 401 after login → set region manually: `mmx config set --key region --value global`
- Key prefix `sk-cp-` = Token Plan (subscription), not pay-as-you-go
- Video is async — poll with `mmx video task get --task-id <id>`, then download
- `npx skills add MiniMax-AI/cli -y -g` fails with "PromptScript does not support global skill installation" → manual symlink: `ln -sf ~/.hermes/skills/minimax-cli/SKILL.md ~/.claude/skills/minimax-cli.md` and same for `~/.openclaw/skills/`
- Output files go to `minimax-output/` in cwd, not to Hermes audio cache
- Old SSE MCP servers (minimax-media :18090, minimax-code :18091) are DEAD. Use mmx-cli or stdio minimax-coding-plan-mcp instead
- Built-in `text_to_speech` tool hits OpenAI 429 quota regularly — don't retry, fall back to edge-tts immediately
