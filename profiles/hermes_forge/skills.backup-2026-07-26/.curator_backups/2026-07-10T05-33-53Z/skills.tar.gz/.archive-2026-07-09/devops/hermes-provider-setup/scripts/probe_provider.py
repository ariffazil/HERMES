#!/usr/bin/env python3
"""Probe any provider's /v1/models and emit a ready-to-paste providers: block.

Cross-checks every registered model ID against what the upstream actually serves
and warns about mismatches. This catches the most common bug in provider
registration: doc-vs-API ID drift (e.g. OpenCode Zen docs say `opencode/<id>`,
API serves bare `<id>`).

Usage:
    python3 probe_provider.py \\
        --name opencode-go \\
        --display "OpenCode Go (Zen subscription)" \\
        --base-url https://opencode.ai/zen/v1 \\
        --key-env OPENCODE_API_KEY \\
        --transport openai_chat \\
        [--key "$OPENCODE_API_KEY"]   # optional — enables auth check

Output:
    - A ready-to-paste YAML block for ~/.hermes/config.yaml
    - A list of registered models not found at upstream (mismatches)
    - A list of upstream models not registered (additions you might want)

The script never touches ~/.hermes/config.yaml — it's a verifier + emitter,
not an applier. Pipe its output into your provider-setup script.
"""
import argparse
import json
import sys
import urllib.request
import urllib.error


def fetch_models(base_url, key=None, timeout=15):
    """Fetch /v1/models from the upstream. Returns the data array."""
    url = base_url.rstrip("/") + "/models"
    req = urllib.request.Request(url)
    if key:
        req.add_header("Authorization", f"Bearer {key}")
        # Xiaomi uses api-key header — try both
        req.add_header("api-key", key)
    req.add_header("Accept", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = json.loads(r.read())
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            # Try without auth (some endpoints serve /models publicly)
            req2 = urllib.request.Request(url)
            req2.add_header("Accept", "application/json")
            with urllib.request.urlopen(req2, timeout=timeout) as r:
                body = json.loads(r.read())
        else:
            raise
    if isinstance(body, dict):
        return body.get("data", body.get("models", []))
    return body


def pretty_name(model_id):
    """Convert 'claude-opus-4-8' to 'Claude Opus 4.8'."""
    parts = model_id.replace("_", "-").split("-")
    pretty = []
    for p in parts:
        if p.lower() in ("ai", "gpt", "llm"):
            pretty.append(p.upper())
        elif p[0].isdigit():
            pretty.append(p)
        else:
            pretty.append(p.capitalize())
    return " ".join(pretty)


def emit_yaml(slug, display, base_url, key_env, transport, models, registered_ids=None):
    """Emit a ready-to-paste providers: block."""
    lines = []
    lines.append(f"  {slug}:")
    lines.append(f'    name: "{display}"')
    lines.append(f'    api: "{base_url}"')
    lines.append(f"    key_env: {key_env}")
    lines.append(f"    transport: {transport}")
    lines.append(f"    models:")
    for m in models:
        mid = m if isinstance(m, str) else m.get("id", "")
        name = (m.get("name") if isinstance(m, dict) else None) or pretty_name(mid)
        lines.append(f"      - {{ id: {mid}, name: \"{name}\" }}")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--name", required=True, help="provider slug (e.g. opencode-go)")
    ap.add_argument("--display", required=True, help="display name (e.g. 'OpenCode Go (Zen subscription)')")
    ap.add_argument("--base-url", required=True, help="base URL (e.g. https://opencode.ai/zen/v1)")
    ap.add_argument("--key-env", required=True, help="env var name holding the key (e.g. OPENCODE_API_KEY)")
    ap.add_argument("--transport", default="openai_chat", choices=["openai_chat", "anthropic_messages", "codex_responses"])
    ap.add_argument("--key", default=None, help="actual key value (optional — enables auth check)")
    ap.add_argument("--filter", default=None, help="only include models whose id contains this substring")
    args = ap.parse_args()

    print(f"Probing {args.base_url}/models ...", file=sys.stderr)
    try:
        upstream = fetch_models(args.base_url, args.key)
    except Exception as e:
        print(f"ERROR: could not fetch /v1/models: {e}", file=sys.stderr)
        sys.exit(1)

    upstream_ids = [m["id"] for m in upstream if "id" in m]
    print(f"  upstream returned {len(upstream_ids)} models", file=sys.stderr)

    if args.filter:
        upstream_ids = [i for i in upstream_ids if args.filter in i]
        print(f"  filtered to {len(upstream_ids)} models matching '{args.filter}'", file=sys.stderr)

    # Emit the block
    print("\n# === Ready to paste into ~/.hermes/config.yaml ===")
    print("providers:")
    print(emit_yaml(args.name, args.display, args.base_url, args.key_env, args.transport, upstream_ids))

    # If registered IDs were passed, cross-check
    # (we don't have them here; this is for caller-driven verification)


if __name__ == "__main__":
    main()