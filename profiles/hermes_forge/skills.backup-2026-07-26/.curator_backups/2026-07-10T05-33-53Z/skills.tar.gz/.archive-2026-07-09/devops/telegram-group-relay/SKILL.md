---
name: telegram-group-relay
description: >
  Relay Telegram group conversations when the user can't access their phone.
  Monitor incoming messages via gateway logs, send responses via hermes send
  or direct Bot API fallback. Real-time group conversation proxy pattern.
triggers:
  - "send telegram to group"
  - "check telegram group messages"
  - "relay message to telegram"
  - "monitor telegram group"
  - "phone in car"
  - "i left my phone"
  - "send message on my behalf"
  - "any message from that group"
  - "telegram group chat"
  - "chat id"
---

# Telegram Group Relay

## When to Use

User is away from phone and needs to monitor/respond to Telegram group conversations through Hermes. Real-time conversation proxy — not bulk operations.

## Architecture

```
User (CLI/Terminal) → Hermes Agent → Telegram Group
                    ← gateway.log ←
```

- **Write path**: `hermes send` or direct Bot API curl
- **Read path**: Gateway log grep (hermes send is write-only)

## Step 1: Find the Chat ID

```bash
# Check channel directory for known groups
cat /root/.hermes/channel_directory.json | python3 -c "
import json, sys
d = json.load(sys.stdin)
for ch in d.get('platforms', {}).get('telegram', []):
    print(f\"{ch['id']:>20}  {ch['name']:<30}  {ch['type']}\")
"
```

Chat ID format: negative number for groups (e.g., `-1003815535761`).
Store it — you'll reuse it for every send/read cycle.

## Step 2: Send Messages

### Primary: `hermes send`

```bash
/usr/local/lib/hermes-agent/venv/bin/python3 /root/.local/bin/hermes send \
  --to "telegram:<CHAT_ID>" \
  "Message text here"
```

### Fallback: Direct Bot API (when hermes send fails)

`hermes send` can fail with "You must pass the token you received from https://t.me/Botfather!" even when the token exists. Cause unclear — possibly env loading race or token format issue.

**Workaround — direct Telegram Bot API:**

```bash
source /root/.hermes/.env 2>/dev/null
TOKEN="${ASI_ARIFOS_BOT_TOKEN}"

# Text message
curl -sf -X POST "https://api.telegram.org/bot${TOKEN}/sendMessage" \
  -d chat_id="<CHAT_ID>" \
  --data-urlencode text="Message text here" \
  2>&1 | python3 -c "import json,sys; d=json.load(sys.stdin); print('OK' if d.get('ok') else d)"

# Photo
curl -sf -X POST "https://api.telegram.org/bot${TOKEN}/sendPhoto" \
  -F chat_id="<CHAT_ID>" \
  -F photo=@/path/to/image.png \
  -F caption="Caption here"

# Document
curl -sf -X POST "https://api.telegram.org/bot${TOKEN}/sendDocument" \
  -F chat_id="<CHAT_ID>" \
  -F document=@/path/to/file.pdf \
  -F caption="Caption here"
```

**Emoji/special chars**: always use `--data-urlencode` for text, not `-d`.

## Step 3: Read Incoming Messages

`hermes send` is write-only. There is no `hermes read` command.

**Read path — gateway log grep:**

```bash
# Recent messages from a specific group
tail -100 /root/.hermes/logs/gateway.log 2>/dev/null \
  | grep "<CHAT_ID>" | grep "inbound" | tail -10

# Full context including photo/media indicators
tail -100 /root/.hermes/logs/gateway.log 2>/dev/null \
  | grep "<CHAT_ID>" | tail -15
```

### Log Line Anatomy

```
INFO gateway.run: inbound message: platform=telegram user=No name chat=-1003815535761 msg='Okey2 boleh2' reply_to_id=None reply_to_text=''
```

- `user=No name` = user has no display name set (common)
- `user=ARIF` = Arif himself (don't report his own messages back)
- `photo batch` line before text = image was attached
- `reply_to_id=<N>` = reply to message N

### Important Caveat

Gateway logs show inbound messages ONLY when the gateway is running AND the group is in its routing config. Messages sent while gateway was down are lost — no retroactive read.

## Step 4: Monitor Loop Pattern

For real-time relay, poll logs every 15-30 seconds:

```bash
# One-shot check — new messages since last check
tail -20 /root/.hermes/logs/gateway.log 2>/dev/null \
  | grep "<CHAT_ID>" | grep "inbound" | grep -v "user=ARIF"
```

Report only OTHER users' messages to the user. Skip the user's own messages (`user=ARIF`).

## Conversation Flow for Real-Time Relay

1. User says "send X to [group]" → compose + send
2. User says "any messages?" → grep gateway logs → report
3. User says "tell him Y" → compose + send to same chat_id
4. Repeat — keep the chat_id cached for the session

## Pitfalls

- **Don't echo the user's own messages** — grep for `user=ARIF` and skip those
- **Photo messages** — logs show "photo batch with N image(s)" but NOT the photo content. If a photo arrives, tell the user "he sent a photo but I can't see the content from logs"
- **Token env var name** — check `/root/.hermes/.env` for the actual name. Current: `ASI_ARIFOS_BOT_TOKEN`. This may change if bot is rotated.
- **Gateway must be running** — if gateway is down, no inbound messages are logged. Check: `ps aux | grep 'hermes.*gateway'`
- **Rate limits** — Telegram limits ~30 msg/sec per group, ~20 msg/min to same topic. Don't spam.
- **Group permissions** — bot must be member of the group to send/read. If `sendMessage` returns `Forbidden`, bot was removed.
- **hermes send can break mid-session** — it worked for the first 3 sends then started failing with token error. Always have the curl fallback ready.

## Related Skills

- `telegram-forum-management` — forum/topic management (create, edit, delete topics)
- `openclaw-channel-config` — bot configuration and channel setup
