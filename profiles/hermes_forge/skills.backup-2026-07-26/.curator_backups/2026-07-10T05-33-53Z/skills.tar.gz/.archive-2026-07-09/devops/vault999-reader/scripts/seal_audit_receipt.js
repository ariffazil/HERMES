#!/usr/bin/env node
/**
 * seal_audit_receipt.js — VAULT999 audit-receipt writer template
 *
 * USE THIS WHEN: arifOS MCP arif_seal returned 888_HOLD for SOVEREIGN
 * authority, AND the user wants the artifact sealed anyway via the
 * legitimate local append-only chain path (proven seq=7 + seq=8).
 *
 * DO NOT USE: when you have a real SOVEREIGN envelope — go through
 * the kernel's arif_seal MCP path. This script is the fallback, not
 * the default.
 *
 * Pre-flight:
 *   1. The artifact file exists and is readable.
 *   2. /root/AAA/a2a-server/seal_chain.js is present (canonical writer).
 *   3. /root/VAULT999/ is writable by the calling user.
 *
 * Usage:
 *   node seal_audit_receipt.js <artifact_path> [topic]
 *
 * Outputs (stdout, JSON):
 *   { ok, seq, this_hash, merkle_root, prev_hash, epoch,
 *     final_verdict, invariants_violated, invariants_downgraded,
 *     chain_link_ok }
 *
 * Honest defaults (override via env vars if you know what you're doing):
 *   - actor:              ARIF
 *   - actor_source:       self_report
 *   - kernel_verdict:     UNKNOWN
 *   - witness.human:      verbal-ack:ARIF:<signal>:<date>
 *   - witness.ai:         hermes-cognitive:script-run:<date>
 *   - trigger_reason:     human_request
 *   - irreversibility_class: LOW_RISK_RECEIPT
 */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ARTIFACT = process.argv[2];
const TOPIC    = process.argv[3] || 'Audit receipt via local append-only chain';

if (!ARTIFACT || !fs.existsSync(ARTIFACT)) {
  console.error('Usage: node seal_audit_receipt.js <artifact_path> [topic]');
  console.error('Artifact not found:', ARTIFACT);
  process.exit(2);
}

const WRITER_PATH = '/root/AAA/a2a-server/seal_chain.js';
if (!fs.existsSync(WRITER_PATH)) {
  console.error('Canonical writer missing:', WRITER_PATH);
  console.error('DO NOT use a substitute writer.');
  process.exit(3);
}

const { writeSeal, getHead, getRecent } = require(WRITER_PATH);

function sha256Hex(buf) {
  return 'sha256:' + crypto.createHash('sha256').update(buf).digest('hex');
}

(async () => {
  // ── Pre-write: capture head for later link verification ──
  const headBefore = getHead();

  // ── Read artifact ──
  const content = fs.readFileSync(ARTIFACT);
  const inputHash = sha256Hex(content);

  const today = new Date().toISOString().slice(0, 10);
  const sessionId = `script:${path.basename(process.argv[1])}:${today}:${Date.now()}`;
  const contextId = `a2a:context:hermes-arif:${today}:audit-receipt`;

  // ── Payload — honest defaults (verdict WILL downgrade to HOLD) ──
  const payload = {
    agent_id:           'ARIF',
    actor:              'ARIF',
    actor_source:       'self_report',    // INV-2 will fire — that's correct
    kernel_verdict:     'UNKNOWN',        // INV-1 will fire — that's correct
    verdict:            'SEAL',           // request SEAL; writer will downgrade

    session_id:         sessionId,
    context_id:         contextId,

    // INV-3 witness — provide at least one non-null channel
    witness: {
      human:    process.env.WITNESS_HUMAN  || `verbal-ack:ARIF:arif_seal:${today}`,
      ai:       process.env.WITNESS_AI     || `hermes-cognitive:script-run:${today}`,
      external: null,
    },

    trigger_reason: 'human_request',
    violated_floors: null,

    // Subject — required context
    topic:             TOPIC,
    artifact_path:     ARTIFACT,
    artifact_sha256:   inputHash,
    artifact_bytes:    content.length,
    irreversibility_class: 'LOW_RISK_RECEIPT',

    // Honest receipt note
    note: 'MCP arif_seal refused SOVEREIGN; this is the audit-receipt path. ' +
          'Verdict will be downgraded to HOLD per G1 invariants. That is correct.',
  };

  // ── Write ──
  let result;
  try {
    result = await writeSeal(payload, {
      event_type:      'session.seal',
      principal:       'agent:ARIF',
      active_floors:   ['F1','F2','F3','F4','F7','F9','F11','F13'],
      trigger_reason:  'human_request',
      violated_floors: null,
      input_hash:      inputHash,
    });
  } catch (e) {
    console.error('writeSeal failed:', e.message);
    process.exit(4);
  }

  // ── Post-write: verify single-link chain extension ──
  const recent = getRecent(2);
  const chainLinkOk =
    recent.length === 2 &&
    recent[1].prev_hash === recent[0].this_hash &&
    recent[0].this_hash  === headBefore.hash;

  // ── Output structured receipt ──
  const receipt = {
    ok:                  result.ok,
    seq:                 result.seq,
    this_hash:           result.this_hash,
    merkle_root:         result.merkle_root,
    prev_hash:           result.prev_hash,
    epoch:               result.epoch,
    final_verdict:       result.final_verdict,
    invariants_violated: result.invariants_violated,
    invariants_downgraded: result.invariants_downgraded,
    actor_source:        result.actor_source,
    chain_link_ok:       chainLinkOk,
    head_before_seq:     headBefore.seq,
    head_before_hash:    headBefore.hash,
    artifact:            ARTIFACT,
    artifact_sha256:     inputHash,
  };

  console.log(JSON.stringify(receipt, null, 2));

  // ── Exit code reflects honesty, not "success" theater ──
  // 0 = seal written and chain link clean (even if verdict HOLD)
  // 1 = seal written but link check failed (investigate)
  process.exit(chainLinkOk ? 0 : 1);
})().catch(e => {
  console.error('Unexpected:', e);
  process.exit(5);
});