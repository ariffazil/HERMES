---
name: openclaw-channel-config
description: "Configure OpenClaw channels (Telegram, Discord, etc.) — custom slash commands, DM/group policies, webhook settings, heartbeat config. Covers the protected-path pitfall where config.patch rejects channel changes and you must edit openclaw.json directly. Also covers the 5-layer diagnostic for 'bot silent in group' (groups allowlist, bindings, unmentionedInbound, Hermes allowed_chats, free_response_chats). Load when the user wants to 'add Telegram commands', 'configure the bot', 'set up slash commands', 'change DM policy', 'wire webhook', 'update heartbeat', 'bot not replying in group', 'make bot respond without mention', or any mutation to channels.* in OpenClaw config."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [openclaw, telegram, discord, channels, slash-commands, bot, config, gateway]
    related_skills: [hermes-agent, hermes-provider-setup]
---

# OpenClaw Channel Configuration

Manage OpenClaw's channel settings — Telegram custom commands, DM/group policies, webhooks, heartbeat, and streaming config.

## When to load

- User says "add slash commands", "configure the bot", "set up Telegram commands"
- User wants to change DM policy, group allowlists, webhook URLs
- User wants to modify heartbeat schedule or target
- Any mutation touching `channels.*` in OpenClaw config
- User says "the bot menu doesn't show my commands"

## Key facts

| Fact | Value |
|------|-------|
| OpenClaw config | `/root/.openclaw/openclaw.json` (JSON) |
| **Hermes config** | **`~/.hermes/config.yaml`** (YAML) — SEPARATE, see `references/hermes-side-telegram-config.md` |
| Protected paths | `channels.*` — `config.patch` REJECTS these |
| Restart method | `mcp_openclaw_gateway(action='restart')` or SIGUSR1 |
| Hot-reload kind | Most channel settings are `hot` — restart not always needed |

**Two gateways, two configs, same bot token.** Both OpenClaw and Hermes have independent Telegram configs. If the bot isn't responding in a group, check BOTH. The Hermes-side config (`telegram:` in config.yaml) controls `allowed_chats`, `free_response_chats`, and `require_mention`.

## The Protected-Path Pitfall (Critical)

**`config.patch` cannot change `channels.*` or `bindings` paths.** It returns:
```
"gateway config.patch cannot change protected config paths: channels.telegram.customCommands"
"gateway config.patch cannot change protected config paths: bindings"
```

**Workaround:** Edit the JSON file directly via Python:

```python
import json

with open('/root/.openclaw/openclaw.json', 'r') as f:
    config = json.load(f)

# Make your changes
config['channels']['telegram']['customCommands'] = [
    {"command": "status", "description": "Federation health"},
    # ...
]

with open('/root/.openclaw/openclaw.json', 'w') as f:
    json.dump(config, f, indent=2)
```

Then restart:
```
mcp_openclaw_gateway(action='restart', reason='Updated Telegram commands')
```

## Schema lookup (before editing)

Always check schema first to know the expected shape:
```
mcp_openclaw_gateway(action='config.schema.lookup', path='channels.telegram.customCommands')
```

Returns `type`, `properties`, `items` — use this to validate your structure before writing.

## Custom Commands Schema

```json
{
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": false,
    "properties": {
      "command": {"type": "string"},
      "description": {"type": "string"}
    }
  }
}
```

- `command` = the slash command name (without `/`)
- `description` = shown in Telegram's bot menu
- No handler/routing field — OpenClaw routes all commands to the agent; the agent interprets intent from the command name + message text

## Common channel config paths

| Path | What it controls |
|------|-----------------|
| `channels.telegram.customCommands` | Bot menu slash commands |
| `channels.telegram.dmPolicy` | `allowlist` or `open` |
| `channels.telegram.allowFrom` | Array of user IDs for DM |
| `channels.telegram.groupPolicy` | `allowlist` or `open` |
| `channels.telegram.groups` | Object of group IDs → config |
| `channels.telegram.groupAllowFrom` | Array of user IDs that bypass mention requirement in groups |
| `channels.telegram.webhookUrl` | Telegram webhook endpoint |
| `channels.telegram.webhookSecret` | Webhook auth secret |
| `channels.telegram.streaming.mode` | `progress` | `full` | `off` |
| `channels.telegram.heartbeat.*` | Heartbeat display config |
| `channels.defaults.botLoopProtection` | Anti-loop limits |
| `messages.groupChat.mentionPatterns` | Array of regex patterns — bot only responds to messages matching these in groups |
| `messages.groupChat.unmentionedInbound` | `user_request` (default), `room_event` (quiet unless mentioned), `respond` (reply to all in allowed groups) |
| `messages.groupChat.visibleReplies` | `message_tool` (agent must use message tool) or `automatic` (normal replies post directly) |

## Group Mention Rules (AAA multi-bot pattern)

When multiple bots share a group (e.g. AAA group with Hermes + OpenClaw +777-FORGE):

**Goal:** Arif can talk freely (no @mention). Agents must @mention each other.

**CRITICAL: Set `unmentionedInbound` FIRST** — without this, the bot responds to ALL messages regardless of mentionPatterns:
```json
{
  "messages": {
    "groupChat": {
      "unmentionedInbound": "room_event",
      "mentionPatterns": ["@AGI_ASI_bot", "@AGI_ASI_bot\\b"]
    }
  }
}
```

**OpenClaw config (`openclaw.json`):**
```json
{
  "channels": {
    "telegram": {
      "groupAllowFrom": ["267378578"],
      "groups": {"-1003753855708": {}}
    }
  },
  "messages": {
    "groupChat": {
      "mentionPatterns": ["@AGI_ASI_bot", "@AGI_ASI_bot\\b"]
    }
  }
}
```

- `groupAllowFrom` = user IDs that bypass mentionPatterns (Arif = 267378578)
- `mentionPatterns` = regex array; only messages matching these trigger the bot
- Result: Arif's messages always get a response; other agents must @mention

**Hermes config (`~/.hermes/config.yaml`):**
```yaml
telegram:
  require_mention: true
  free_response_chats: ["267378578"]
```

**777-FORGE bot (`bot.py`):** Has `should_respond_in_group()` function with `ALLOWED_USER_ID` bypass. Code-level, not config-level.

## 000-999 Reality Loop Commands

The canonical slash command surface for the arifOS federation:

| Cmd | Stage | Meaning |
|-----|-------|---------|
| `/000` | INIT | Reset session, fresh identity boot |
| `/111` | OBSERVE | MCP tools, scan, discover |
| `/222` | THINK | Reason, plan, critique |
| `/333` | ROUTE | Organ status, routing |
| `/444` | ACT | Execute action (governed) |
| `/555` | VERIFY | Reality check, GEOX anchor |
| `/666` | HEART | Risk, ethics, critique |
| `/777` | FORGE | Build, deploy, code |
| `/888` | JUDGE | Verdict, seal, hold |
| `/999` | VAULT | Receipt, seal, memory |

Plus utility aliases: `/status`, `/model`, `/image`, `/email`

Both OpenClaw and777-FORGE should register these. When aligning, update both:
1. OpenClaw: `openclaw.json → channels.telegram.customCommands`
2. 777-FORGE: `bot.py → COMMANDS` list + `CommandHandler` registrations

## Webhook Routing Pitfall (Critical)

The OpenClaw gateway webhook listener runs on port **8787** (not the main gateway port 18789).

```
Telegram POST → openclaw.arif-fazil.com/telegram-webhook
  → Caddy reverse_proxy → 127.0.0.1:8787/telegram-webhook (webhook listener)
```

**If Caddy proxies to 18789:** The main gateway returns HTML (200), not webhook handler. Telegram sees "Wrong response: 404" or HTML. Updates silently queue then drop.

**Verification:**
```bash
curl -s -o /dev/null -w "%{http_code}" -X POST http://127.0.0.1:8787/telegram-webhook
# Expected: 401 (secret token check) — this means webhook listener is alive
curl -s -o /dev/null -w "%{http_code}" -X POST http://127.0.0.1:18789/telegram-webhook
# Expected: 404 or HTML — this is the WRONG port for webhooks
```

**Fix:** Edit `/etc/caddy/Caddyfile`:
```
handle /telegram-webhook {
    reverse_proxy 127.0.0.1:8787
}
```
Then `caddy reload --config /etc/caddy/Caddyfile`.

**After fixing, re-register webhook:**
```bash
source /root/.secrets/vault.flat.env
curl -s "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
  --data-urlencode "url=https://openclaw.arif-fazil.com/telegram-webhook" \
  --data-urlencode "secret_token=${TELEGRAM_WEBHOOK_SECRET}" \
  --data-urlencode 'allowed_updates=["message","edited_message","callback_query","message_reaction"]'
```

## Multi-Bot Token Verification

When debugging "token conflict" claims, verify with SHA256 hashes — never trust displayed prefixes (terminal redacts paths containing "token"):

```bash
for var in ASI_BOT_TOKEN TELEGRAM_BOT_TOKEN FORGE_BOT_TOKEN; do
  val=$(printenv $var)
  echo "$var sha256=$(echo -n "$val" | sha256sum | cut -c1-8)"
done
```

Also verify bot identity via Telegram API:
```bash
curl -s "https://api.telegram.org/bot${TOKEN}/getMe" | jq '.result | {username, id}'
```

**Terminal redaction trap:** The terminal tool redacts paths/strings containing "token", "secret", "key". A TOKEN_PATH showing as `"...ot"` is NOT broken — it's redacted. Verify with Python exec:
```python
from pathlib import Path
exec(open('bot.py').read().split('TOKEN_PATH')[1].split('\n')[0])
print(TOKEN_PATH.exists())  # True = file is fine
```

## Adding Telegram IDs (Allowlist + Bindings)

When adding user IDs or group IDs, three config sections need updating:

### 1. `allowFrom` — DM access
Array of Telegram user ID strings. Users listed here can DM the bot.
```json
"allowFrom": ["267378578", "1042200555"]
```

### 2. `groups` — Group access
Object of group ID strings → config objects. Groups listed here + bot is a member = bot responds.
```json
"groups": {
  "-1003753855708": {},
  "-1003792478194": {},
  "-1003768847825": {}
}
```

### 3. `bindings` — Agent routing
Each group needs a binding to route messages to an agent. Structure:
```json
{
  "agentId": "main",
  "match": {
    "channel": "telegram",
    "peer": {
      "kind": "group",
      "id": "-1003768847825"
    }
  }
}
```

**Without a binding, the group message has no agent to route to.** The group will be allowed but messages may be dropped or fall to default.

### Full edit script (Python):
```python
import json

with open('/root/.openclaw/openclaw.json') as f:
    cfg = json.load(f)

new_user_ids = ["1042200555"]
new_group_ids = ["-1003768847825", "-1003521544074"]

# 1. Add users to allowFrom
for uid in new_user_ids:
    if uid not in cfg['channels']['telegram']['allowFrom']:
        cfg['channels']['telegram']['allowFrom'].append(uid)

# 2. Add groups
for gid in new_group_ids:
    if gid not in cfg['channels']['telegram']['groups']:
        cfg['channels']['telegram']['groups'][gid] = {}

# 3. Add bindings for new groups
existing_binding_ids = {
    b['match']['peer']['id']
    for b in cfg['bindings']
    if 'peer' in b.get('match', {})
}
for gid in new_group_ids:
    if gid not in existing_binding_ids:
        cfg['bindings'].append({
            'agentId': 'main',
            'match': {
                'channel': 'telegram',
                'peer': {'kind': 'group', 'id': gid}
            }
        })

with open('/root/.openclaw/openclaw.json', 'w') as f:
    json.dump(cfg, f, indent=2)
```

Then restart: `mcp_openclaw_gateway(action='restart', reason='Added Telegram IDs')`

## Pitfall: sed appending to YAML lists breaks indentation (2026-07-07)

**Symptom:** After using `sed -i "/pattern/a\\"` to append items to `free_response_chats` in `config.yaml`, the YAML becomes invalid:
```yaml
  free_response_chats:
  - '-1003792478194'
    - '-1003768847825'    # ← WRONG: extra 2-space indent
    - '-1003521544074'    # ← WRONG
  - '267378578'
```

**Root cause:** `sed` appends lines after a match but doesn't know YAML indentation context. Appended lines get whatever indent the sed command specifies, which rarely matches existing list items.

**Fix:** Use Python `str.replace()` to rewrite the entire telegram section clean:
1. `cat ~/.hermes/config.yaml | grep -A 20 "^telegram:"` — get exact current text
2. Build `old_section` and `new_section` strings with correct 2-space YAML indentation
3. `content = content.replace(old_section.strip(), new_section.strip())`
4. Write back ONCE, verify with grep

**Lesson (2026-07-07):** Agent used sed to add 4 groups to `free_response_chats`. Result had mixed indentation. YAML parsed items as nested sub-items. Had to rewrite entire telegram section with Python.

**Safe pattern for bulk edits:** Backup → read with Python → make ALL changes in memory → write ONCE → verify → restart. Don't chain multiple sed calls.

## Pitfall: `hermes send` doesn't load .env automatically

```bash
hermes send -t "telegram:-1003792478194" "test"
# → "Telegram send failed: You must pass the token you received from https://t.me/Botfather!"
```

**Root cause:** `hermes send` uses the gateway's platform credentials from `~/.hermes/.env`, but the subprocess doesn't auto-source the `.env` file. The `ASI_ARIFOS_BOT_TOKEN` (or whatever `bot_token_env` is set to) isn't in the environment.

**Fix — source .env first, then use direct Telegram Bot API curl:**
```bash
source ~/.hermes/.env 2>/dev/null
curl -s -X POST "https://api.telegram.org/bot${ASI_ARIFOS_BOT_TOKEN}/sendMessage" \
  -d chat_id="-1003792478194" \
  -d text="Test message" | python3 -c "import json,sys; r=json.load(sys.stdin); print('✅ sent' if r.get('ok') else f'❌ {r.get(\"description\",\"?\")}')"
```

**This is also the most reliable verification method** after config changes — curl directly to Telegram API proves the bot token is valid AND the chat_id is reachable, bypassing both Hermes and OpenClaw gateways entirely.

**Batch verification pattern (all groups at once):**
```bash
source ~/.hermes/.env 2>/dev/null
for gid in "-1003753855708" "-1003792478194" "-1003768847825"; do
  curl -s -X POST "https://api.telegram.org/bot${ASI_ARIFOS_BOT_TOKEN}/sendMessage" \
    -d chat_id="$gid" -d text="⚡ ASI Test ✅" | \
    python3 -c "import json,sys; r=json.load(sys.stdin); print(f'✅ $gid' if r.get('ok') else f'❌ $gid: {r}')"
done
```

**Lesson (2026-07-07):** Agent tried `hermes send` 3 times before discovering the .env issue. Direct curl worked immediately. Always use curl for verification sends — it's the ground truth.

## Pitfall: `hermes config set` can't set list values or negative chat IDs

```bash
hermes config set telegram.allowed_chats '-1003792478194'
# → error: unrecognized arguments: -1003792478194
```

The `-` prefix is parsed as a CLI flag. No quoting trick works. Use Python YAML editing instead (see `references/hermes-side-telegram-config.md` for the full script).

## Pitfall: groups dict ≠ bindings (silent routing gap)

A group can be listed in `channels.telegram.groups` (so the bot accepts messages) but have NO corresponding entry in `bindings[]` (so no agent is routed to process those messages). The group appears "enabled" but messages are silently dropped or fall to default binding.

**Detection:** After adding a group to `groups`, always verify a binding exists:
```python
import json
with open('/root/.openclaw/openclaw.json') as f:
    cfg = json.load(f)
groups = set(cfg.get('channels',{}).get('telegram',{}).get('groups',{}).keys())
binding_ids = {
    b['match']['peer']['id']
    for b in cfg.get('bindings',[])
    if 'peer' in b.get('match',{})
}
missing_bindings = groups - binding_ids
if missing_bindings:
    print(f"Groups WITHOUT bindings (silent routing gap): {missing_bindings}")
```

**Fix:** Add binding entry (see "Adding Telegram IDs" section above).

**Lesson (2026-07-06):** Dear NABILAH group (`-1003792478194`) was in `groups` but had no binding — messages would have been unrouted.

## Pitfall: `allowed_chats` format may be string OR list

Depending on how the config was last edited, `allowed_chats` may be a comma-separated string (`'-1001,-1002'`) or a YAML list (`- '-1001'\n- '-1002'`). Always use Python's `yaml.safe_load` to read it (handles both), never assume one format.

## Pitfall: `TELEGRAM_HOME_CHANNEL_THREAD_ID=""` causes silent 400 hammering loop (2026-07-09)

**Symptom:** OpenClaw gateway logs spam `400: Bad Request: message thread not found` 10-30×/minute. Every outbound reply attempt fails the same way. User never receives anything. Process appears alive, gateway uptime is fine, **but all delivery is silently broken**.

**Root cause:** `TELEGRAM_HOME_CHANNEL_THREAD_ID` set in env/`vault.flat.env` to one of:
- Empty string `""` — bot includes `message_thread_id=""` → Telegram rejects with 400
- Stale integer from a deleted/archived topic → 400
- Typo / wrong chat's thread_id → 400

The gateway crashes on each send and retries indefinitely. No DLQ, no circuit-breaker, no exponential backoff beyond Telegram's HTTP-level rate limit.

**Three-step diagnostic:**

```bash
# 1. Confirm the symptom (count the repetitions)
journalctl -u openclaw-gateway.service --since "1 hour ago" | grep -c "message thread not found"

# 2. Read the thread_id the running process actually has
sudo cat /proc/$(pgrep -f openclaw | head -1)/environ | tr '\0' '\n' | grep TELEGRAM_HOME_CHANNEL_THREAD_ID

# 3. Verify the configured topic still exists in the target chat
curl -s "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getChat?chat_id=<TELEGRAM_HOME_CHANNEL>" | jq .result
# Look at result.is_forum and the topics list
```

**Three fix options (by blast radius):**

| Fix | What | Reversibility | Blast |
|---|---|---|---|
| **1. Clear thread_id, post to chat main** | `systemctl edit openclaw-gateway.service` → remove `Environment=TELEGRAM_HOME_CHANNEL_THREAD_ID=...` line. Restart. Messages land in main chat, no topic. | FULL | LOW |
| **2. Re-create topic, get fresh ID** | In Telegram: create new topic in Home channel. URL is `https://t.me/c/<chat>/<N>` — N is the new `message_thread_id`. Update env, restart. | FULL | LOW |
| **3. Patch gateway to skip invalid thread_id** | Code fix in OpenClaw Telegram handler — only include `message_thread_id` if it's a non-empty integer. Requires upstream patch. | FULL (with rollback) | MEDIUM |

Fix 1 is fastest. Fix 2 is what you want if topics are intentional. Fix 3 is the long-term architectural fix.

**Defensive code pattern (Fix 3, reference for upstream PR):**

```typescript
const threadId = process.env.TELEGRAM_HOME_CHANNEL_THREAD_ID;
const messageThreadId = (threadId && /^-?\d+$/.test(threadId)) ? Number(threadId) : undefined;
const body = { chat_id, text,
  ...(messageThreadId !== undefined && { message_thread_id: messageThreadId }) };
```

**Lesson:** This is a class of silent-failure bug common across all chat platforms where routing metadata (thread/topic/room) is misconfigured. Always guard metadata inclusion; never pass empty strings into API params that expect integers.

**Related to:** Pitfall 17 (`getUpdates` polling cleanly ≠ messages being processed) — same family.

## Pitfall: config.patch works for NON-channel paths

`config.patch` works fine for `agents.*`, `mcp.*`, `tools.*`, `plugins.*`, etc. Only `channels.*` is protected. Don't assume all paths need the Python-edit workaround — try `config.patch` first, fall back to direct edit only if you get the protected-path error.

## Diagnostic: "Bot silent in group" (5-point checklist)

When the bot is a member of a Telegram group but doesn't reply to messages, check ALL FIVE layers. Any single failure = silence.

| # | Layer | Where to check | What to look for |
|---|-------|---------------|-----------------|
| 1 | **OC group allowlist** | `openclaw.json → channels.telegram.groups` | Group ID must be a key in the dict |
| 2 | **OC agent binding** | `openclaw.json → bindings[]` | Entry with `match.peer.id` = group ID. **Missing binding = silent routing gap** |
| 3 | **OC unmentionedInbound** | `openclaw.json → messages.groupChat.unmentionedInbound` | `room_event` = only @mentioned messages processed. `respond` = ALL messages answered |
| 4 | **Hermes allowed_chats** | `~/.hermes/config.yaml → telegram.allowed_chats` | Group ID must be in list |
| 5 | **Hermes free_response_chats** | `~/.hermes/config.yaml → telegram.free_response_chats` | Group ID must be here to bypass `require_mention: true` |

**Quick diagnostic script:**
```python
import json, yaml

GROUP_ID = '-1003792478194'  # target group

# OpenClaw checks
with open('/root/.openclaw/openclaw.json') as f:
    oc = json.load(f)

in_groups = GROUP_ID in oc.get('channels',{}).get('telegram',{}).get('groups',{})
in_bindings = any(
    b.get('match',{}).get('peer',{}).get('id') == GROUP_ID
    for b in oc.get('bindings', [])
)
unmentioned = oc.get('messages',{}).get('groupChat',{}).get('unmentionedInbound','NOT SET')
group_allow = oc.get('channels',{}).get('telegram',{}).get('groupAllowFrom',[])

# Hermes checks
with open('/root/.hermes/config.yaml') as f:
    hermes = yaml.safe_load(f)

h_allowed = GROUP_ID in hermes.get('telegram',{}).get('allowed_chats',[])
h_free = GROUP_ID in hermes.get('telegram',{}).get('free_response_chats',[])
h_require = hermes.get('telegram',{}).get('require_mention', True)

print(f"Group {GROUP_ID} diagnosis:")
print(f"  OC groups allowlist:   {'✅' if in_groups else '❌ MISSING'}")
print(f"  OC agent binding:      {'✅' if in_bindings else '❌ MISSING — messages dropped!'}")
print(f"  OC unmentionedInbound: {unmentioned} {'⚠️ bot only responds to @mention' if unmentioned == 'room_event' else ''}")
print(f"  OC groupAllowFrom:     {group_allow}")
print(f"  Hermes allowed_chats:  {'✅' if h_allowed else '❌ MISSING'}")
print(f"  Hermes free_response:  {'✅' if h_free else '❌ MISSING — needs @mention' if h_require else '✅ (require_mention=false)'}")
```

**Common failure combos:**
- **Group in OC `groups` but no binding** → messages accepted but never routed to agent (silent)
- **`unmentionedInbound: room_event` + group not in `groupAllowFrom`** → only @mentioned messages processed
- **Group in OC but NOT in Hermes `allowed_chats`** → OC routes to Hermes, Hermes rejects
- **Group in Hermes `allowed_chats` but NOT in `free_response_chats`** + `require_mention: true` → bot needs @mention

**The fix for "reply to everything, no @mention" requires ALL of:**
1. Group in OC `groups` dict
2. Group in OC `bindings[]` with agent routing
3. OC `unmentionedInbound` = `respond`
4. Group in Hermes `allowed_chats`
5. Group in Hermes `free_response_chats`

**Lesson (2026-07-07):** Nabilah group (`-1003792478194`) had gaps at layers 2+3+5. Was in OC `groups` but had no binding AND `unmentionedInbound` was `room_event`. Hermes had it in `allowed_chats` but initially not in `free_response_chats`.

## Audit: "What Telegram bots are wired up?" (2026-07-09)

When Arif asks "tell me about my telegram apps", "what bots are active", "do a full audit" — or names a specific bot that may or may not exist — run this 4-step probe before saying anything. Don't trust config files alone; the live API is the truth surface.

**Step 1 — Find every config layer that mentions Telegram:**

```bash
# OpenClaw (primary gateway)
ls ~/.openclaw/openclaw.json ~/.openclaw/.env ~/.openclaw/.env.decrypted ~/.openclaw/gateway.env 2>/dev/null

# Hermes (separate, may be running in parallel)
ls ~/.hermes/config.yaml ~/.hermes/.env 2>/dev/null

# Vault
ls /root/.secrets/vault.flat.env /root/.secrets/vault.env 2>/dev/null
```

**Step 2 — Extract bot tokens and key facts (do NOT echo tokens):**

```bash
for f in ~/.openclaw/.env ~/.openclaw/.env.decrypted ~/.hermes/.env /root/.secrets/vault.flat.env; do
  [ -f "$f" ] && grep -E "^[A-Z_]*BOT_TOKEN|^TELEGRAM_" "$f" 2>/dev/null | sed 's/=.*/=<REDACTED>/' | sed "s|^|$f: |"
done
```

**Step 3 — Verify identity and webhook live:**

```bash
# Source the env that holds the active token
source /root/.secrets/vault.flat.env 2>/dev/null
TOKEN_VAR=$(grep -hoE "ASI_ARIFOS_BOT_TOKEN|TELEGRAM_BOT_TOKEN|ASI_BOT_TOKEN|FORGE_BOT_TOKEN" \
  ~/.hermes/config.yaml ~/.openclaw/openclaw.json 2>/dev/null | head -1)
TOKEN=$(eval echo \$$TOKEN_VAR)

curl -s "https://api.telegram.org/bot${TOKEN}/getMe" | python3 -m json.tool
curl -s "https://api.telegram.org/bot${TOKEN}/getWebhookInfo" | python3 -m json.tool
```

**What to record per bot:**
- `result.id` — bot numeric ID (unique, ties all configs together)
- `result.username` — public handle
- `result.first_name` — display name
- `webhook_info.url` — where Telegram POSTs updates
- `webhook_info.pending_update_count` — backlog (0 = healthy)
- `webhook_info.allowed_updates` — what event types are accepted

**Step 4 — Cross-check config layers:**

| Layer | File | Key paths |
|-------|------|-----------|
| **OpenClaw gateway** | `~/.openclaw/openclaw.json` | `channels.telegram.{enabled, dmPolicy, allowFrom, groupPolicy, groups, customCommands}` |
| **OpenClaw bindings** | `bindings[]` | Each group's `match.peer.id` → `agentId` |
| **OpenClaw behavior** | `messages.groupChat.{unmentionedInbound, mentionPatterns}` | Group response policy |
| **Hermes-side** | `~/.hermes/config.yaml` → `telegram:` | `streaming`, `reactions`, `allowed_chats`, `free_response_chats`, `require_mention`, `bot_token_env` |
| **Hermes heartbeat** | `openclaw.json → agents.defaults.heartbeat` | Target, interval, active hours |
| **Devices** | `~/.openclaw/devices/paired.json` | Local operator device (not Telegram, but the agent receiving the bot's messages) |
| **API truth** | `getMe` / `getWebhookInfo` | Live identity, live routing |

**If Arif names a bot you can't find:** Don't fabricate it. Check ALL the above. If absent, present a 3-option menu:

1. Paste the bot @handle — I'll probe `getMe` with the right token
2. Point me to the file/skill where you saw it
3. It doesn't exist — set it up fresh (need: bot token, target chat/group, standalone vs wired to arifOS pipeline)

**Lesson (2026-07-09):** Arif asked "what's the difference between the bot I use and the TLIB Telegram bot under TLIB investigations." No such TLIB bot existed in any config layer, the device registry, or the chat history (session_search + grep across `/root`). Correct response: enumerate the ACTUAL bots wired up, show the 4-step audit result, then ask for the missing identifier rather than invent one. Fabricating a bot's identity (even a plausible-sounding one) would create a permanent false reference that future sessions would cite against the user.

**Common finding patterns:**
- "I have 1 bot" — usually wrong. OpenClaw + Hermes often run 2-3 distinct bot tokens in parallel (gateway bot, workspace bot, A-FORGE bot)
- Same bot token in 3 env files (vault + .env + .env.decrypted) — verify they all match by SHA256 prefix, not by visual inspection
- Custom commands defined in `customCommands` but missing from `getMyCommands` — config drift, push via `setMyCommands`
- `free_response_chats` includes Arif's user ID as a string — this is the bypass for `require_mention: true` in DMs

## Bot Token Rotation (when bot returns 404)

**Symptom:** All Telegram API calls return 404: `getMe failed: (404: Not Found)`, `sendMessage failed: (404: Not Found)`. Bot appears completely dead — no DM, no group responses.

**Root cause:** Bot token expired, revoked, or replaced via @BotFather. The token in the env files no longer matches what Telegram expects.

**Diagnostic:**
```bash
# Check journal for 404 pattern
journalctl -u openclaw-gateway --since "10 min ago" 2>/dev/null | grep "404: Not Found"
# Expected: getMe, sendMessage, setMyCommands all returning 404
```

**Token storage — THREE files must be updated:**

| File | Used by | Format |
|------|---------|--------|
| `/root/.secrets/vault.flat.env` | systemd service (`EnvironmentFile`) | `TELEGRAM_BOT_TOKEN="..."` |
| `/root/.openclaw/.env` | OpenClaw gateway (dotenv) | `TELEGRAM_BOT_TOKEN=...` |
| `/root/.openclaw/.env.decrypted` | OpenClaw decrypted vault | `TELEGRAM_BOT_TOKEN=...` |

**Fix — use Python, NOT sed (token truncation pitfall):**

```python
NEW_TOKEN = "1234567890:AAxxxxxx..."  # full token from @BotFather

# 1. vault.flat.env — NO 'export' prefix (systemd EnvironmentFile)
# 2. vault.env — WITH 'export' prefix (bash source)
# 3. .env — plain text (dotenv loader)
# 4. .env.decrypted — plain text (reference copy)

import re
files = {
    '/root/.secrets/vault.flat.env': False,  # no export
    '/root/.secrets/vault.env': True,         # with export
    '/root/.openclaw/.env': False,
    '/root/.openclaw/.env.decrypted': False,
}
for fpath, use_export in files.items():
    with open(fpath) as f:
        lines = f.readlines()
    new_lines = []
    found = False
    for line in lines:
        if 'TELEGRAM_BOT_TOKEN' in line and not line.strip().startswith('#'):
            prefix = 'export TELEGRAM_BOT_TOKEN=' if use_export else 'TELEGRAM_BOT_TOKEN='
            new_lines.append(f'{prefix}"{NEW_TOKEN}"\n')
            found = True
        else:
            new_lines.append(line)
    if found:
        with open(fpath, 'w') as f:
            f.writelines(new_lines)
        print(f"Updated {fpath}")
    else:
        print(f"NOT FOUND in {fpath}")

# Verify length (should be 46-50 chars for typical Telegram bot token)
for fpath in files:
    with open(fpath) as f:
        for line in f:
            if 'TELEGRAM_BOT_TOKEN' in line and not line.strip().startswith('#'):
                m = re.search(r'"([^"]+)"', line)
                if m:
                    print(f"  {fpath}: len={len(m.group(1))} bot_id={m.group(1).split(':')[0]}")
```

**Restart + verify:**
```bash
systemctl restart openclaw-gateway.service
sleep 15
journalctl -u openclaw-gateway --since "20s ago" | grep -i "starting provider\|getMe\|webhook\|error"
# Expected: "starting provider (@NewBotName)" + "webhook advertised" + NO 404 errors
```

**Pitfall: sed regex truncates tokens.** Telegram bot tokens contain `:` which sed regex `.*` may mishandle when the shell interpolates. Always use Python for token edits. Verify token length (46-50 chars) after every edit — truncated tokens produce 404 on getMe.

**Pitfall: SOPS-encrypted .env overrides vault.env.** The `.env` file at `/root/.openclaw/.env` may contain `TELEGRAM_BOT_TOKEN=ENC[AES256_GCM,...]` — SOPS-encrypted values that the node process decrypts at startup. If present, this OVERRIDES the vault.env value. Options:
1. Remove the TELEGRAM_BOT_TOKEN line from the encrypted `.env` entirely (vault.env becomes source)
2. Update the encrypted value via `sops --in-place /root/.openclaw/.env` (if sops key is available)
3. Add a plain text `TELEGRAM_BOT_TOKEN=...` line to `.env` (takes precedence over ENC[] lines)

**Pitfall: vault.env vs vault.flat.env format difference.**
- `vault.env` (sourced by `openclaw-gateway-secure.sh`): uses `export KEY="value"` format
- `vault.flat.env` (systemd `EnvironmentFile`): uses `KEY="value"` format — **NO `export` prefix**
- Mixing formats causes the gateway to see empty values for required secrets

**Pitfall: QWEN_API_KEY and other required secrets.** The gateway validates required secrets (from config `${VAR}` references) during startup, BEFORE sourcing vault.env. If a required secret is only in vault.env but not in vault.flat.env or .env, startup fails with `SecretRefResolutionError`. Check all `${VAR}` refs in openclaw.json and ensure they exist in at least one loaded env file.

**Related skill:** `hermes-provider-setup` for Hermes-side bot token (different bot, different config path).

## Pitfall: dual systemd services fighting for port 18789

**Symptom:** Gateway fails with `EADDRINUSE: address already in use 127.0.0.1:18789` even after `systemctl restart`. Journal shows "gateway already running under systemd; existing gateway is healthy, exiting with code 78."

**Root cause:** TWO systemd services manage OpenClaw — a system-level unit (`/etc/systemd/system/openclaw-gateway.service`) AND a user-level unit (`~/.config/systemd/user/openclaw-gateway.service`). Both try to bind port 18789. They take turns crashing.

**Diagnostic:**
```bash
# Check for both service levels
systemctl status openclaw-gateway.service 2>/dev/null | head -3        # system-level
systemctl --user status openclaw-gateway.service 2>/dev/null | head -3  # user-level

# Check what's holding the port
ss -tlnp | grep 18789
fuser 18789/tcp 2>/dev/null
```

**Fix:** Disable the user-level service, keep system-level:
```bash
systemctl --user stop openclaw-gateway.service 2>/dev/null
systemctl --user disable openclaw-gateway.service 2>/dev/null
# Also stop the restart watcher if present
systemctl stop openclaw-restart.path 2>/dev/null
systemctl stop openclaw-restart.service 2>/dev/null
# Kill anything on the port
fuser -k 18789/tcp 2>/dev/null; sleep 2
# Restart cleanly
systemctl start openclaw-gateway.service
```

**Lesson:** The system-level unit (`openclaw-gateway.service` in `/etc/systemd/system/`) is the canonical one. The user-level unit is a leftover from an earlier install. Don't let both coexist.

## Pitfall: SOPS-encrypted .env overrides vault.env (token rotation)

When rotating the bot token, the SOPS-encrypted `/root/.openclaw/.env` **overrides** values from `vault.env`. The gateway script sources `vault.env` first, but the node process then loads `.env` via dotenv — the `.env` values win.

**Symptom:** Updated vault.env and vault.flat.env with new token, gateway still uses old token (404 errors persist).

**Fix:** Either:
1. Add plain-text `TELEGRAM_BOT_TOKEN=*** line to `.env` (before any `ENC[` lines) — plain text wins over encrypted
2. Remove `TELEGRAM_BOT_TOKEN` line from `.env` entirely — forces vault.env as source

**Also:** The `.env` must contain `QWEN_API_KEY` even though vault.env has it — gateway validates required secrets at startup BEFORE vault.env is sourced. If restoring `.env` from an old SOPS backup, add any missing required keys.

**Detailed fix sequence:** `references/bot-token-rotation-2026-07-05.md`

## Pitfall: vault.flat.env does NOT support `export` prefix

Systemd `EnvironmentFile` requires `KEY="value"` format. If you write `export KEY="value"`, systemd silently ignores the line. The gateway reports `Environment variable "X" is missing or empty`.

**Fix:** Always strip `export` prefix when writing to `vault.flat.env`. The `vault.env` file (sourced by bash) supports `export` — these are different formats for different consumers.

## Pitfall: bot echoes/responds to every group message (unmentionedInbound)

**Symptom:** Bot responds to ALL messages in a group, not just @mentions. Every user message gets a reply — looks like an echo machine.

**Root cause:** `messages.groupChat.unmentionedInbound` is not set. Default behavior treats every group message as a `user_request`, so the agent processes and responds to all of them.

**This is DIFFERENT from the forum-topic echo** (below) — that one is a self-message loop. This one is about the bot responding to OTHER people's messages.

**Fix:** Set `unmentionedInbound` to `room_event`:
```python
import json
with open('/root/.openclaw/openclaw.json') as f:
    cfg = json.load(f)
cfg['messages']['groupChat']['unmentionedInbound'] = 'room_event'
with open('/root/.openclaw/openclaw.json', 'w') as f:
    json.dump(cfg, f, indent=2)
```
Then restart: `mcp_openclaw_gateway(action='restart', reason='Fixed group echo: unmentionedInbound=room_event')`

**Values:**
- `user_request` (default when unset) — bot responds to every group message
- `room_event` — bot stays quiet unless explicitly @mentioned or in `groupAllowFrom`
- `respond` — bot responds to ALL messages in allowed groups, no @mention needed

**This should be set on EVERY OpenClaw install that uses groups.** Without it, the bot floods groups with unwanted responses.

**IMPORTANT:** `room_event` can ALSO cause the opposite problem — the bot goes completely silent in groups because it only processes messages as "room events" (logged but not answered). If user wants the bot to reply to ALL messages in specific groups without @mention, use `respond` instead. See "Bot silent in group" diagnostic below.

**Per-group override (preferred for selective behavior):** You can set `unmentionedInbound` per-group in the `groups` dict instead of globally. This is cleaner when you want some groups to be "respond all" and others to stay quiet unless mentioned:

```python
import json
with open('/root/.openclaw/openclaw.json') as f:
    cfg = json.load(f)

groups = cfg['channels']['telegram']['groups']
for gid in groups:
    groups[gid]['unmentionedInbound'] = 'respond'

with open('/root/.openclaw/openclaw.json', 'w') as f:
    json.dump(cfg, f, indent=2)
```

Per-group setting overrides the global `messages.groupChat.unmentionedInbound`. Use this when adding multiple groups at once — set it in the same Python script that adds the groups to the allowlist.

## Pitfall: bot messages echo back in Telegram forum topics

**Symptom:** When the bot sends a message to a Telegram forum topic, the message appears to echo back — the agent sees its own response as a new inbound message and responds again, creating a loop.

**Root cause:** OpenClaw's Telegram handler does NOT filter the bot's own messages on the inbound path. When the bot sends a message to a forum topic, Telegram delivers that message back as an update. OpenClaw processes it as a new inbound message because there's no `msg.from?.id === botUserId` check.

**Evidence from source (`/usr/lib/node_modules/openclaw/dist/bot-r6hl6ztC.js`):**
- Discord handler has explicit `author.id !== params.botUserId` check (line 1067 of `message-handler.preflight`)
- Telegram handler's `buildTelegramMessageContext` (line 4301) never compares `msg.from?.id` against the bot's own ID
- `botLoopProtection` config exists in `channels.defaults` but is only wired into the Discord path
- `wasSentByBot()` function exists (checks sent message cache) but is only used for reaction filtering, not message filtering

**Current status:** Bug in OpenClaw. No config option exists to fix it.

**Workarounds:**
1. **Webhook-level filter** — add a reverse proxy rule to drop updates where `from.is_bot=true` before they reach OpenClaw (not yet implemented)
2. **File upstream issue** — Telegram handler needs the same self-message filter Discord has
3. **Avoid forum topics** — echo only happens in forum topics (thread_id), not DMs or regular groups

**The `botLoopProtection` config is NOT the fix:**
```json
{
  "channels": {
    "defaults": {
      "botLoopProtection": {
        "maxEventsPerWindow": 5,
        "windowSeconds": 60,
        "cooldownSeconds": 120
      }
    }
  }
}
```
This only rate-limits OTHER bots. It does not filter the bot's own messages. The Telegram handler doesn't reference this config at all.

## Pitfall: allowlist ≠ bot can reach (Three-Level Verification)

Adding an ID to the config does NOT guarantee the bot can send/receive messages. Three levels must pass:

| Level | Check | Failure mode |
|-------|-------|-------------|
| **Config** | ID in `allowFrom`/`groups` + binding exists | Messages silently dropped |
| **Telegram membership** | Bot is admin/member of the group, or user started DM | `chat not found` or `bot was kicked` error |
| **API accept** | Telegram API returns 200 on sendMessage | Rate limit, blocked, deactivated |

**After adding IDs, always test with actual sends:**
```
mcp_openclaw_message(action='send', channel='telegram', message='🟢 test', target='<id>')
```

Common errors:
- `"chat not found"` — bot was never added to this group, or group ID is wrong
- `"bot was kicked from the supergroup chat"` — bot was removed; re-add it in Telegram
- `"bot is not a member of the chat"` — same as kicked
- User DM fails — user must `/start` the bot first

**Don't just add IDs and assume it works. Test each one.**

## Pitfall: customCommands in config ≠ registered with Telegram

**Symptom:** Commands are defined in `openclaw.json → channels.telegram.customCommands` but don't appear when user types `/` in Telegram.

**Root cause:** OpenClaw registers commands via Telegram's `setMyCommands` API on startup. If the registration step failed silently (token rotation, webhook reset, or startup timing issue), Telegram's server-side command list drifts from config. Config says one thing; Telegram API says another.

**Fix:** Push commands directly via Telegram Bot API:
```bash
source /root/.secrets/vault.flat.env
curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setMyCommands" \
  -H "Content-Type: application/json" \
  -d '{"commands": [...]}'
```
Verify: `curl -s "https://api.telegram.org/bot${TOKEN}/getMyCommands" | python3 -m json.tool`

**Lesson (2026-07-09):** Config defines commands, but Telegram's API is the truth surface. When the `/` menu doesn't show expected commands, verify with `getMyCommands` and re-push via `setMyCommands`.

## Pitfall: gateway restart clears active sessions

Restarting the gateway (SIGUSR1) kills active agent sessions. If you're in a long-running session, the restart will interrupt it. Plan accordingly — batch all config changes, then restart once.

## Pitfall: measure before acting on "broken" claims

When the user says something is broken or asks you to add something, **verify current state first** before proposing or executing fixes. The most common mistake: re-wiring commands, re-enabling services, or re-building things that are already live.

**Pattern:**
1. `cat /root/.openclaw/openclaw.json | python3 -c "import json,sys; c=json.load(sys.stdin); print(len(c.get('channels',{}).get('telegram',{}).get('customCommands',[])))"` — check if commands already exist
2. `curl -sf http://localhost:<port>/health` — check if service is already running
3. `ps aux | grep <process>` — check if process is already alive

**Only act on what's actually missing.** If everything is already wired, say so — don't rebuild it to look productive.

**Lesson (2026-07-04):** Agent proposed adding /status, /model, /think commands that were already wired (25/25 live). Arif: "Reality wins. Don't fix what's already done. Measure first, then act."

## Verification

After config changes + restart:
1. Check bot menu in Telegram — type `/` to see registered commands
2. `mcp_openclaw_gateway(action='config.get')` — verify the parsed config shows your changes
3. Test a command — `/status` or any registered command

## Related

- `hermes-provider-setup` — LLM provider config (different system: Hermes vs OpenClaw)
- `hermes-agent` (bundled) — broader Hermes Agent config reference
- `references/telegram-command-wiring-2026-07-04.md` — session-specific detail on wiring 25 commands
- `references/telegram-3-bot-architecture-2026-07-03.md` — 3-bot token map, webhook routing, mention rules, verification commands
- `references/telegram-allowlist-addition-2026-07-05.md` — step-by-step allowlist + bindings workflow with test results
- `references/cross-system-group-audit.md` — audit technique: resolve group IDs to names via Telegram API, find Hermes↔OpenClaw gaps, three-level verification
