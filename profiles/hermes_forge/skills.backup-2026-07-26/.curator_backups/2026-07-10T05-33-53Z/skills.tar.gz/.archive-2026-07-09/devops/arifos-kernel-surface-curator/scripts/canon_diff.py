#!/usr/bin/env python3
"""
canon_diff.py — Compare current CANONICAL_N against a target set, emit a
patch plan: which tools to promote, which to demote, which to add, which
to remove.

Usage:
    cd /root/arifOS && python3 arifosmcp/_tools/canon_diff.py \\
        --target arif_init,arif_canary,arif_triage,arif_observe,arif_fetch,arif_think,arif_route,arif_critique,arif_bridge_connect,arif_judge,arif_forge,arif_compose

Or read target from a YAML/JSON file:

    python3 canon_diff.py --target-file target_canon.json
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


ARIFOS_ROOT = Path("/root/arifOS")


def load_current_canon() -> tuple[str, ...]:
    os.environ.pop("ARIFOS_PUBLIC_SURFACE_MODE", None)
    os.environ.pop("ARIFOS_PUBLIC_TOOL_PROFILE", None)
    sys.path.insert(0, str(ARIFOS_ROOT))
    try:
        from arifosmcp.runtime.public_surface import CANONICAL_12  # type: ignore
        return tuple(CANONICAL_12)  # type: ignore
    except ImportError:
        from arifosmcp.runtime.public_surface import CANONICAL_7  # type: ignore
        return tuple(CANONICAL_7)  # type: ignore


def load_constitutional_tools() -> dict:
    sys.path.insert(0, str(ARIFOS_ROOT))
    from arifosmcp.constitutional_map import CANONICAL_TOOLS  # type: ignore
    return dict(CANONICAL_TOOLS)


def main() -> int:
    parser = argparse.ArgumentParser(description="Compare arifOS canon against target")
    parser.add_argument("--target", help="Comma-separated target canon (ordered)")
    parser.add_argument("--target-file", help="JSON file with target canon array")
    args = parser.parse_args()

    if args.target_file:
        with open(args.target_file) as f:
            target = json.load(f)
        target = tuple(target)
    elif args.target:
        target = tuple(t.strip() for t in args.target.split(","))
    else:
        parser.error("Provide --target or --target-file")

    current = load_current_canon()
    canonical_tools = load_constitutional_tools()

    print(f"═══ Canon Diff ═══")
    print(f"Current ({len(current)}): {list(current)}")
    print(f"Target  ({len(target)}): {list(target)}")
    print()

    # Promote: target has, current doesn't
    to_promote = [n for n in target if n not in current]
    # Demote: current has, target doesn't
    to_demote = [n for n in current if n not in target]
    # Common: in both
    common = [n for n in target if n in current]
    # Reorder: in both but different position
    reorder = []
    for i, n in enumerate(target):
        if n in current and current.index(n) != i:
            reorder.append((n, current.index(n), i))

    print(f"═══ Patch Plan ═══")
    print()
    print(f"Promote ({len(to_promote)}): {to_promote}")
    for n in to_promote:
        if n in canonical_tools:
            spec = canonical_tools[n]
            print(f"  - {n}: expose={spec.get('expose')} access={spec.get('access')}")
            print(f"    → action: set expose=True, access=<current access>, add to _PUBLIC_N")
        else:
            print(f"  - {n}: NOT in CANONICAL_TOOLS (lives in DIAGNOSTIC_TOOLS — verify)")
    print()
    print(f"Demote ({len(to_demote)}): {to_demote}")
    for n in to_demote:
        if n in canonical_tools:
            print(f"  - {n}: action: set expose=False, access='internal_only', remove from _PUBLIC_N")
        else:
            print(f"  - {n}: action: remove from CANONICAL_N tuple")
    print()
    print(f"Common ({len(common)}): {common}")
    if reorder:
        print(f"Reorder ({len(reorder)}):")
        for n, old_i, new_i in reorder:
            print(f"  - {n}: position {old_i} → {new_i}")

    print()
    print(f"═══ Files to Patch ═══")
    print("1. arifosmcp/constitutional_map.py")
    print(f"   - Add {len(to_promote)} tool(s) to _PUBLIC_N frozenset")
    print(f"   - Remove {len(to_demote)} tool(s) from _PUBLIC_N")
    print(f"   - Flip {len(to_promote)} expose=True flags")
    print(f"   - Flip {len(to_demote)} expose=False flags")
    print()
    print("2. arifosmcp/runtime/public_surface.py")
    print(f"   - Replace CANONICAL_N tuple with target")
    print(f"   - Update normalize_public_surface_mode() profile_map (add canonical{N})")
    print()
    print("3. arifosmcp/tool_registry.json")
    print(f"   - Replace canonical_order array with target")
    print(f"   - Add demoted tools to internal_canonical_order")
    print()
    print("4. arifosmcp/PUBLIC_SURFACE_CANON.md")
    print(f"   - Rewrite tool table ({len(target)} rows)")
    print()
    print("5. tests/test_public_surface_invariants.py")
    print(f"   - Update EXPECTED_CANONICAL_N to {{...{len(target)} names...}}")
    print(f"   - Update test_canonical_N_exact_count: == {len(target)}")
    print(f"   - Update test_default_public_tools_exactly_N: == {len(target)}")
    print(f"   - Update test_canonical_N_ordered: expected_order = {list(target)}")
    print()
    print("6. tests/test_public_tool_registry.py")
    print(f"   - Update expected_canonical set with target")

    return 0


if __name__ == "__main__":
    sys.exit(main())