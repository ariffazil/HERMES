# MiMo V2.5 Series — Multimodal Configuration Reference (2026-07-06)

## Models

| Model ID | Type | Capabilities | Token Plan Cost |
|----------|------|-------------|-----------------|
| `mimo-v2.5-pro` | Text reasoning | Deep thinking, structured output, tool calling | Input (cache hit): 2.5 credits, Input (cache miss): 300 credits, Output: 600 credits |
| `mimo-v2.5` | Multimodal | Image + audio + video understanding | Input (cache hit): 2 credits, Input (cache miss): 100 credits, Output: 200 credits |
| `mimo-v2.5-asr` | Speech recognition | Audio → text | 30M credits per hour of audio |
| `mimo-v2.5-tts` | Speech synthesis | Text → speech (voice clone, voice design variants available) | FREE (limited time promotion) |

## Provider config (xiaomi-mimo Token Plan SGP)

```yaml
providers:
  xiaomi-mimo:
    name: Xiaomi MiMo (Token Plan SGP)
    api: https://token-plan-sgp.xiaomimimo.com/v1
    key_env: XIAOMI_API_KEY
    transport: openai_chat
    models:
      - id: mimo-v2.5-pro
        name: MiMo-V2.5-Pro
      - id: mimo-v2.5
        name: MiMo-V2.5
```

## Auxiliary vision config

```yaml
auxiliary:
  vision:
    provider: xiaomi-mimo
    model: mimo-v2.5          # NOT mimo-v2.5-pro (text-only)
    timeout: 120
```

## MiMo V2.5 capabilities (from vendor docs)

- **Image understanding**: up to 16M pixels per image, multi-image input
- **Video understanding**: up to 2h video, 2GB max
- **Audio understanding**: accepts audio input for analysis
- **Speech recognition (ASR)**: dedicated model, billed per audio duration
- **Speech synthesis (TTS)**: text-to-speech with voice clone and voice design variants
- **Deep thinking**: mimo-v2.5-pro supports extended reasoning chains
- **Structured output**: JSON output from visual/text input
- **Tool calling**: function calling support on mimo-v2.5-pro
- **Web search**: built-in web search capability

## V2 deprecation notice

MiMo-V2 series (mimo-v2-pro, mimo-v2-omni, mimo-v2-tts) deprecated June 30, 2026.
Migrate to V2.5 series. V2 models may still work but will be removed.

## Hermes native support gaps

| MiMo capability | Hermes native? | Current Hermes alternative |
|----------------|---------------|---------------------------|
| Vision (auxiliary) | ✅ via auxiliary.vision | — |
| Main model | ✅ via model.default | — |
| STT (ASR) | ❌ | local faster-whisper, groq, openai whisper, mistral |
| TTS | ❌ | edge (free), elevenlabs, openai, minimax, mistral, neutts |

## Token plan pricing (from vendor FAQ)

- Packages: Lite, Standard, Pro, Max (monthly or annual)
- Night discount (0:00-8:00 Beijing Time = 16:00-24:00 UTC): 0.8x consumption coefficient
- First purchase: 12% off (one-time)
- Annual subscription: 12% off vs monthly
- TTS all models: FREE for limited time

## Probe command

```bash
curl -sS -H "Authorization: Bearer $XIAOMI_API_KEY" \
  https://token-plan-sgp.xiaomimimo.com/v1/models | python3 -c "
import sys,json
d=json.load(sys.stdin)
for m in d.get('data',[]): print(m['id'])
"
```

## Availability on other providers

MiMo V2.5 models are also available through OpenCode Go (proxy):

| Provider | Model | Rate limit (Go sub) |
|----------|-------|-------------------|
| xiaomi-mimo (direct) | mimo-v2.5-pro | MiMo Token Plan quota |
| xiaomi-mimo (direct) | mimo-v2.5 | MiMo Token Plan quota |
| opencode-go (proxy) | mimo-v2.5-pro | 3,250 req/5h |
| opencode-go (proxy) | mimo-v2.5 | 30,100 req/5h |

Direct provider is preferred for primary use (better rate limits, full multimodal). OpenCode Go is useful as a secondary access point when MiMo Token Plan quota is exhausted.
