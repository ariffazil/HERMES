#!/usr/bin/env bash
# probe_mcp_session.sh — Verify MCP session handshake works for a federation organ
# Usage: ./probe_mcp_session.sh <port>   (e.g. 8081 for GEOX, 8088 for arifOS)

set -euo pipefail

PORT="${1:?Usage: $0 <port>}"
URL="http://localhost:${PORT}/mcp"

echo "=== Probing MCP session on :${PORT} ==="

# 1. Initialize
SID=$(curl -s -X POST "$URL" \
  -H 'Content-Type: application/json' \
  -H 'Accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"probe","version":"1.0"}}}' \
  -i | grep -i 'mcp-session-id' | head -1 | sed 's/.*: //;s/\r//')

if [ -z "$SID" ]; then
  echo "❌ No mcp-session-id returned from initialize"
  exit 1
fi
echo "✅ Session ID: ${SID:0:16}..."

# 2. Send notifications/initialized
curl -s -X POST "$URL" \
  -H 'Content-Type: application/json' \
  -H 'Accept: application/json, text/event-stream' \
  -H 'MCP-Protocol-Version: 2025-11-25' \
  -H "mcp-session-id: $SID" \
  -d '{"jsonrpc":"2.0","method":"notifications/initialized","params":{}}' > /dev/null
echo "✅ notifications/initialized sent"

# 3. Probe an evidence-lane tool (no session needed) — atlas for GEOX, observe for arifOS
if [ "$PORT" = "8081" ]; then
  PROBE_TOOL='{"name":"geox_atlas","arguments":{"lat":6.075,"lon":116.557,"mode":"context"}}'
  EXPECT_FIELD="country"
elif [ "$PORT" = "8088" ]; then
  PROBE_TOOL='{"name":"arif_route","arguments":{"intent":"probe session"}}'
  EXPECT_FIELD="organ"
else
  PROBE_TOOL='{"name":"tools_list_does_not_matter","arguments":{}}'
  EXPECT_FIELD="result"
fi

RESP=$(curl -s -X POST "$URL" \
  -H 'Content-Type: application/json' \
  -H 'Accept: application/json, text/event-stream' \
  -H 'MCP-Protocol-Version: 2025-11-25' \
  -H "mcp-session-id: $SID" \
  -d "{\"jsonrpc\":\"2.0\",\"id\":2,\"method\":\"tools/call\",\"params\":${PROBE_TOOL}}")

if echo "$RESP" | grep -q "$EXPECT_FIELD"; then
  echo "✅ Probe tool returned expected field '$EXPECT_FIELD'"
  echo "    (session handshake fully working)"
else
  echo "❌ Probe tool response did not contain '$EXPECT_FIELD'"
  echo "    Response: ${RESP:0:300}"
  exit 1
fi

echo ""
echo "✅ MCP session on :${PORT} is fully functional."
echo "   Use this SID for subsequent calls: $SID"