---
name: hermes-prime-federation-map
description: "Map of the arifOS federation — organs, ports, roles, MCP surfaces, health probes. Load when Arif asks 'what organs are alive', 'show me the federation', 'is X running', 'what port is Y', or when you need to route a task to the right organ."
tags: [federation, arifos, organs, mcp, health, routing]
triggers:
  - "federation"
  - "organs"
  - "what's running"
  - "is X alive"
  - "health check"
  - "arifos"
  - "geox"
  - "wealth"
  - "well"
  - "a-forge"
  - "aaa"
  - "cognitive architecture"
  - "LeCun modules"
---

# Hermes Federation Map

## The Six Active Organs

| Organ | Repo | Port | Role | MCP Tools |
|-------|------|------|------|-----------|
| **arifOS (Ω)** | ariffazil/arifOS | 8088 | Constitutional kernel — F1-F13, 888 JUDGE, VAULT999 | `arif_*` — 12 exposed via MCP (17 loaded, 58 declared; exposed = public facade) |
| **GEOX 🌍** | ariffazil/geox | 8081 | Earth intelligence — wells, seismic, petrophysics | `geox_*` — 87 tools via /tools (own MCP server, stateful sessions) |
| **WEALTH 💰** | ariffazil/wealth | 18082 | Capital intelligence — NPV, risk, stock analysis | `wealth_*` — 50 tools via /tools (own MCP server, stateless) |
| **WELL 🫀** | ariffazil/well | 18083 | Human readiness — sleep, fatigue, dignity | `well_*` — 18 tools via /tools (own MCP server, stateless) |
| **A-FORGE ⚒️** | ariffazil/A-FORGE | 7071 (HTTP) / 7072 (MCP) | Execution shell — build, deploy, orchestrate | `forge_*` — 40 tools (execution, leases, proxies) |
| **AAA 🖥️** | ariffazil/AAA | 3001 | Control plane — A2A gateway, cockpit dashboard | A2A server, deliberation |

**APEX (:3002)** — DECOMMISSIONED. Deliberation absorbed into AAA a2a-server.

## Health Probe

```bash
for svc in "arifos:8088" "aforge:7072" "aaa:3001" "geox:8081" "wealth:18082" "well:18083"; do
  name="${svc%%:*}"; port="${svc##*:}"
  curl -sf "http://localhost:$port/health" >/dev/null 2>&1 && echo "✅ $name :$port" || echo "❌ $name :$port"
done
```

## Explorer Organ Roles (2026-07-06)

The federation is not just "tools" — it's a governed explorer civilization. Each agent has a structural role in the OBSERVE→HYPOTHESIZE→FALSIFY→VERIFY loop:

| Agent | Explorer Role | Function | Loop Stage |
|-------|--------------|----------|------------|
| **Hermes** | Explorer Intelligence Router | Routes queries, dispatches stages, gap-elicitor, contradiction-surfer | All (orchestrator) |
| **OpenClaw** | Physical Executor | Executes code, runs tests, deploys, falsifies | VERIFY + FALSIFY |
| **OpenCode** | Cognitive Generator | Generates hypotheses, alternative solutions, design exploration | HYPOTHESIZE |
| **arifOS** | Judge | Verdicts (SEAL/SABAR/HOLD/VOID), floor checks | Governance gate |
| **AAA** | Civilization Layer | Identity, leases, domain_law, agent lifecycle | Authority binding |
| **A-FORGE** | Forge | Tool birth, fitness testing, mutation, retirement | Evolution |

**Governance chain:** All three explorer agents are governed by APEX THEORY, judged by arifOS kernel, civilized by AAA, evolved by A-FORGE.

**Schemas:** Knowledge graph, intent route, and explorer packet schemas at `/root/AAA/docs/schemas/`. See `apex-governance` skill → `references/explorer-protocol-schemas.md` for full specification.

## Constitutional Separation (Brain / Hands)

- **arifOS MCP (8088)** = sovereign governor — floors, judgment, VAULT999, INIT→JUDGE→SEAL
- **A-FORGE MCP (7072)** = governed actuator — `forge_*` execution, leases, proxies
- A-FORGE **never** adjudicates. All high-risk execution requires lease + prior arifOS judgment.

## MCP = Capability, arifOS = Authority

```
MCP says: "I can do this."
arifOS says: "Are you allowed to?"
```

## Intent Routing via `arif_route` (Federation Default, 2026-07-04)

For ambiguous intents ("interpret seismic section", "assess portfolio risk"), arifOS kernel tool `arif_route` resolves to the right organ + tool prefix. Verified working:

```bash
curl -s -X POST http://127.0.0.1:8088/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call",
       "params":{"name":"arif_route",
                 "arguments":{"intent":"interpret seismic section"}}}'
# → {"result":{"intent":"interpret seismic section",
#              "organ":"GEOX","port":8081,"tool_prefix":"geox_",
#              "routing_confidence":0.85,"verdict":"SYUBHAH"}}
```

**Why this matters:** Federation routing should not depend on the agent pattern-matching tool prefixes by hand. `arif_route` makes intent → organ a kernel concern, not an LLM concern.

**Hermes wiring (added 2026-07-04, reversible):**

```yaml
# ~/.hermes/config.yaml
hooks:
  pre_mcp_call:
    enabled: true
    type: intent_route
    endpoint: http://127.0.0.1:8088/mcp
    tool: arif_route
    fallback_on_error: passthrough    # safe default — direct call if router unreachable
    cache_routes: true
    cache_ttl_seconds: 300
    applies_to_toolsets: [federation, mcp, aforge, arifos, geox, wealth, well]

hooks_auto_accept: true   # allow this hook to fire without per-call approval

federation:
  router:
    enabled: true
    default: arif_route
    organs:
      GEOX:    {host: 127.0.0.1, port: 8081,  prefix: geox_}
      WEALTH:  {host: 127.0.0.1, port: 18082, prefix: wealth_}
      WELL:    {host: 127.0.0.1, port: 18083, prefix: well_}
      A-FORGE: {host: 127.0.0.1, port: 7072,  prefix: forge_}
      arifOS:  {host: 127.0.0.1, port: 8088,  prefix: arif_}
      HERMES:  {host: 127.0.0.1, port: 18086, prefix: hermes_}
```

Activates on gateway restart: `systemctl --user restart hermes-gateway` or `hermes gateway run --replace`.

**Pitfall:** This hook is a config declaration. Hermes v0.17.0 must support `pre_mcp_call` hook firing. If gateway rejects the config on restart, the `fallback_on_error: passthrough` keeps federation working — but routing is degraded (manual pattern-matching returns). Verify after restart with a test call that should hit `arif_route` first.

## Tool Discovery

Run `arif_retrieve_tools(query="*")` via arifOS MCP to discover ALL tools across all organs.
Check `https://mcp.arif-fazil.com/manifest/tools.json` for the public 7-tool surface.

## MCP Surfaces (Non-Organ)

| MCP Server | Status | Tools | Purpose |
|-----------|--------|-------|---------|
| **stealth-browser** | ✅ LIVE | 31 | nodriver + CDP. Anti-bot bypass. Navigate, click, type, screenshot, JS eval, cookies, forms, tabs. Idle reaper at 600s. |

Config: `openclaw.json > mcp.servers.stealth-browser`
Server: `/root/stealth-browser-mcp/src/server.py`
Venv: `/root/stealth-browser-mcp/venv/bin/python`

## Telegram Bot Infrastructure (3 bots, verified 2026-07-04)

| Bot Handle | Bot ID | Display Name | Env Var | Gateway |
|---|---|---|---|---|
| `@AGI_ASI_bot` | 8149595687 | AGI🦞 | `TELEGRAM_BOT_TOKEN` | OpenClaw gateway (:18789) |
| `@ASI_arifos_bot` | 8410138119 | ASI💃 | `HERMES_TELEGRAM_BOT_TOKEN` = `ASI_BOT_TOKEN` | Hermes gateway (polling) |
| `@arifOS_bot` | 8727562763 | 777 FORGE | `TELEGRAM_OPENCODE_BOT_TOKEN` | OpenCode bot.py (polling) |

All three can be in the AAA group (-1003753855708) simultaneously. Each has independent model quotas.
Full details: `federation-organ-liveness-probe` → `references/telegram-bot-infrastructure.md`.

## Telegram Mini App (Federation Surface, 2026-07-09)

A Telegram Mini App exists at `/root/AAA/telegram-miniapp/` — MCP-powered intelligence overlay accessible via Telegram WebView.

| Component | Tech | Port | Purpose |
|---|---|---|---|
| API Gateway | Hono | 3100 | Proxies HTTP → MCP JSON-RPC to all organs |
| Mini App | React + Vite | 5173 | Dark-theme UI: Explore, Wealth, Well, Status pages |
| Bot | grammY | — | Entry point, opens WebView |

**MCP session management:** GEOX + arifOS are stateful (initialize → session-id → tools/call); WEALTH + WELL are stateless. 5-min TTL on sessions.

**Deploy:**
```bash
cd /root/AAA/telegram-miniapp
cp .env.example .env  # set BOT_TOKEN
# Docker: docker-compose up -d
# Or direct: pnpm dev:api & pnpm dev:app & pnpm dev:bot
```
Caddy route needed: `app.arif-fazil.com → :5173`.

**No mock data** — every API call hits real MCP servers via JSON-RPC 2.0 protocol.

## Tool-Count Probe Pattern (2026-07-09)

Live tool counts diverge from documented counts. Use this to verify before reporting:

```bash
for port in 8088 8081 18082 18083 7072; do
  count=$(curl -sf "http://localhost:$port/tools" 2>/dev/null | python3 -c "
import json,sys
try:
    d=json.load(sys.stdin)
    t=d.get('tools',d) if isinstance(d,dict) else d
    print(len(t))
except: print(0)
" 2>/dev/null)
  echo "Port $port: $count tools"
done
```

**Pitfall:** Static gateway pages (e.g. `mcp.arif-fazil.com`) can have hardcoded counts that drift from live `/tools` endpoints. Always probe `localhost:<port>/tools` directly — never trust a static page or AGENTS.md numbers without verification. The canonical distinction for arifOS: `tools_exposed_via_mcp` (public facade, what `/tools` returns) ≠ `loaded` (internal) ≠ `declared` (blueprint).

## LeCun Cognitive Architecture Mapping (2026-07-07)

arifOS implements all 6 of LeCun's cognitive modules for autonomous intelligence (2022 position paper) plus a 7th:

| LeCun Module | arifOS Implementation | Organ |
|---|---|---|
| Configurator | `arif_init()` session config | arifOS |
| Perception | GEOX/WEALTH/WELL observe tools | GEOX/WEALTH/WELL |
| World Model | `arif_think` + `forge_reality_loop` | arifOS/A-FORGE |
| Cost | `forge_evaluate` (APEX: G = A·P·E·X·Φ) | A-FORGE |
| Actor | `forge_execute` + `forge_shell` | A-FORGE |
| Short-term Memory | VAULT999 + seal chain + memory | arifOS |
| **Governance** (LeCun doesn't have) | F1-F13, constitutional floors, sovereign veto | arifOS |

**Implication:** The federation is a cognitive architecture for autonomous intelligence with an additional governance layer that LeCun's design lacks. Full mapping, JEPA family tree, and J-space synthesis in `references/j-space-jepa-synthesis.md`.

## Pitfalls

- If an organ is ❌, proceed read-only on live organs. Do NOT assume dead organ's config is valid.
- Never declare a tool absent without probing the full surface first (`forge_registry_status` + `arif_retrieve_tools` + `forge_docs_lookup` + FS scan + `:port/health`).
- Negative capability is allowed only with proved absence.

## Pitfall: startup banner "failed" ≠ service down (2026-07-04)

The Hermes startup banner shows MCP discovery status per server. A `(streamable-http) — failed` line means **discovery probe at boot missed**, NOT that the service is down. Verified by direct curl:

```bash
# Banner said: "openclaw (streamable-http) — failed"
# Reality:
curl -sf http://127.0.0.1:18789/health
# → {"ok":true,"status":"live"}
```

**Rule:** the only ground truth for "is X alive" is `curl -sf http://localhost:PORT/health` (or the equivalent for non-HTTP services). Banner state is a startup snapshot that can be stale, partially probed, or hit during transient service warmup. Always probe live before reporting an organ as down.

## Standalone Hermes MCP (port 18086, hermes_mcp.py)

A standalone Hermes MCP server exists at `/root/.hermes/mcp_servers/hermes_mcp.py` exposing read-only governance tools (`hermes_system_status`, `hermes_epistemic_check`, `hermes_fact_check`, `hermes_cross_verify`, `hermes_plan_review`, `hermes_memory_steward`). Transport: streamable HTTP. Port: 18086.

These were originally embedded in arifOS kernel and extracted 2026-06-28 — they are diagnostic tools, NOT constitutional judgment tools.

**Status (verified 2026-07-04):** Server file exists and is importable, but is NOT registered in `~/.hermes/config.yaml` under `mcp_servers:`. The 6 configured MCPs are the organ ones (arifOS, A-FORGE, GEOX, WEALTH, WELL, OpenClaw). To activate hermes_mcp, add:

```yaml
mcp_servers:
  hermes:
    url: http://127.0.0.1:18086/mcp
    transport: streamable-http
    description: Hermes Agent — read-only governance diagnostics
```

Then `hermes --yolo gateway restart` to pick it up.

## Path symmetry: /root/.hermes ↔ /root/HERMES

`/root/HERMES` is a symlink to `/root/.hermes` — same content, two paths. File writes can land on either depending on which path the tool resolves. `ls -la` to confirm before relying on path-based cleanup or monitoring scripts. Don't try to "consolidate" the two — it's already one filesystem.

## Absorbed Federation Infra Fragments (2026-07-08)

5 standalone federation skills consolidated into this map.

| Fragment | Core Contribution | Status |
|----------|------------------|--------|
| `a2a-federation-builder` | A2A agent card format, federation mesh wiring, agent registration lifecycle | Absorbed |
| `aaa-cockpit` | AAA dashboard architecture, React component map, shadcn/ui primitives | Absorbed |
| `federation-observability` | Prometheus/Grafana config, health probe patterns, Netdata integration | Absorbed |
| `federation-safety-wiring` | Cross-organ safety interlocks, blast radius containment, denylist patterns | Absorbed |
| `federation-topology-map` | Organ port map, dependency graph, routing decision tree | Absorbed — see Six Active Organs table above |

**Provenance:** All 5 fragments archived 2026-07-08 to `.agents/skills/.archive-2026-07-08/`.

## References

- `references/multi-perspective-human-mapping.md` — when Arif needs strategic clarity about multi-person institutional dynamics. Ground claims in direct evidence (WhatsApp quotes, not inference). Per-person strategy, never lumped.
- `references/arifos-health-snapshot-2026-07-04.md` — full health envelope captured
  this session: build vs runtime drift, floor weights, capability map, ML/langfuse/
  token-pressure state. Use as baseline when probing "did arifOS drift since last
  audit?".
- Explorer protocol schemas at `/root/AAA/docs/schemas/` — knowledge-graph.schema.yaml (555-ASI nodes/edges), intent-route.schema.yaml (classify→route→verdict), explorer-packet.schema.yaml (OBSERVE→HYPOTHESIZE→FALSIFY→VERIFY loop). Full spec in `apex-governance` skill → `references/explorer-protocol-schemas.md`.


---

## §PROVENANCE · 2026-07-08 Consolidation

This skill absorbed core knowledge from **5** doctrine fragments during the skill library cleanup (Steps 1-4). Source fragments archived to `/root/.agents/skills/.archive-2026-07-08/`.

**Source fragments:**
  - `a2a-federation-builder` (archived 2026-07-08)
  - `aaa-cockpit` (archived 2026-07-08)
  - `federation-observability` (archived 2026-07-08)
  - `federation-safety-wiring` (archived 2026-07-08)
  - `federation-topology-map` (archived 2026-07-08)

**Full enrichment document:** [`references/consolidation-2026-07-08.md`](references/consolidation-2026-07-08.md) — detailed extraction of unique core knowledge from each fragment.

**F4 ΔS verified:** Entropy reduced — 5 fragments merged → 1 surfaced skill.
