#!/usr/bin/env bash
# asi_audit_pre_flight.sh — dual-agent proof + 7-organ process probe
# Validated 2026-07-04. Sourced from asi-readiness-audit-contract skill.
# Exit 0 = pre-flight passed. Non-zero = audit is INVALID until remediated.

set -uo pipefail

echo "═══ PRE-FLIGHT: dual-agent + 7-organ ═══"
FAIL=0

# Gate 1: Hermes (ASI) alive
HERMES_PID=$(pgrep -f 'hermes.*gateway' | head -1)
if [ -z "$HERMES_PID" ]; then
  echo "❌ Hermes (ASI) dead"
  FAIL=1
else
  echo "✅ Hermes alive  (pid=$HERMES_PID)"
fi

# Gate 2: OpenClaw (AGI) alive
OC_PID=$(pgrep -f 'openclaw.*gateway' | head -1)
if [ -z "$OC_PID" ]; then
  echo "❌ OpenClaw (AGI) dead"
  FAIL=1
else
  echo "✅ OpenClaw alive (pid=$OC_PID)"
fi

# Gate 3: distinct processes
if [ -n "$HERMES_PID" ] && [ -n "$OC_PID" ] && [ "$HERMES_PID" != "$OC_PID" ]; then
  echo "✅ Distinct processes (not one agent cosplaying)"
else
  echo "❌ PIDs match or missing — cannot claim distinct"
  FAIL=1
fi

# Gate 4: 7 organs listening on canonical ports
declare -A PORTS=(
  [arifOS]=8088
  [AFORGE_MCP]=7072
  [AFORGE_EXEC]=7071
  [AAA]=3001
  [GEOX]=8081
  [WEALTH]=18082
  [WELL]=18083
)

LIVE_COUNT=0
for organ in "${!PORTS[@]}"; do
  port="${PORTS[$organ]}"
  if ss -tlnp 2>/dev/null | grep -qE ":${port}\s"; then
    echo "✅ $organ :$port listening"
    LIVE_COUNT=$((LIVE_COUNT + 1))
  else
    echo "❌ $organ :$port NOT listening"
    FAIL=1
  fi
done

# Gate 5: A2A card coverage (informational — flag gap, don't fail)
CARD_HITS=0
for port in 8088 7072 7071 3001 8081 18082 18083 18789; do
  if curl -sf -m 2 "http://localhost:$port/.well-known/agent.json" >/dev/null 2>&1; then
    CARD_HITS=$((CARD_HITS + 1))
  fi
done
echo "ℹ️  A2A card servers exposing .well-known/agent.json: $CARD_HITS/8 (5–6 expected)"

# Gate 6: VAULT999 ledger exists (Memory substrate)
if [ -d /root/VAULT999 ] && [ "$(ls -A /root/VAULT999 2>/dev/null | wc -l)" -gt 0 ]; then
  VAULT_FILES=$(ls /root/VAULT999 2>/dev/null | wc -l)
  echo "✅ VAULT999 has $VAULT_FILES sealed files"
else
  echo "❌ VAULT999 missing or empty — Memory substrate broken"
  FAIL=1
fi

# Gate 7: Constitutional floors documented
if [ -f /root/AAA/docs/INVARIANTS.md ]; then
  INV_LINES=$(wc -l < /root/AAA/docs/INVARIANTS.md)
  if [ "$INV_LINES" -gt 100 ]; then
    echo "✅ INVARIANTS.md has $INV_LINES lines (F1-F13 documented)"
  else
    echo "⚠️  INVARIANTS.md exists but only $INV_LINES lines — too thin"
  fi
else
  echo "❌ INVARIANTS.md missing"
  FAIL=1
fi

echo ""
echo "═══ ORGANS LIVE: $LIVE_COUNT / 7 ═══"
if [ $LIVE_COUNT -lt 6 ]; then
  echo "❌ Less than 6 organs alive — federation not at ASI-ready pre-flight"
  FAIL=1
else
  echo "✅ Pre-flight threshold met (≥6 organs)"
fi

echo ""
if [ $FAIL -eq 0 ]; then
  echo "═══ PRE-FLIGHT: PASS ═══"
  echo "Audit may proceed. Next: run 49-cell matrix + 5-axis meta-layer."
  exit 0
else
  echo "═══ PRE-FLIGHT: FAIL ═══"
  echo "Audit invalid until remediated. Restore missing organs/processes first."
  exit 1
fi
