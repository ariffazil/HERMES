---
name: claim-validation-protocol
description: Audit external AI claims against live system state. Methodology for validating hype, overclaims, and architectural assertions from Copilot, ChatGPT, or other AI assistants against actual running infrastructure. Use when Arif shares an external AI's assessment of arifOS/federation and asks "is this true?"
tags: [validation, audit, epistemology, evidence, reality-check, anti-hype]
triggers:
  - "audit this claim"
  - "is this true"
  - "validate what copilot said"
  - "external AI said"
  - "review this assessment"
  - "fact check"
  - "is this accurate"
  - "overclaim"
  - "hype check"
---

# Claim Validation Protocol

## When to Use

When Arif shares output from Copilot, ChatGPT, Gemini, or any external AI that makes claims about the arifOS federation, and asks "is this true?" or "audit this."

## Core Principle

**External AI claims are INT (interpreted) until verified against OBS (observed live state).** Never validate a claim by agreeing with its framing. Validate by probing reality.

## The Protocol

### Step 1: Identify Claim Class

Each claim falls into one of four classes:

| Class | Description | Verification Method |
|-------|-------------|-------------------|
| **FACT** | Specific measurable claim | Probe live system (curl, ps, registry check) |
| **ARCHITECTURE** | Structural/design claim | Check code, config, file existence |
| **ASPIRATION** | "Will become" / "can become" | Label as SPEC, don't verify |
| **HYPE** | "First in world" / "never done before" | Web search for counter-evidence |

### Step 2: Probe Live State

Before accepting ANY claim about the federation:

```bash
# Organ liveness
for svc in arifos:8088 aforge:7071 aaa:3001 geox:8081 wealth:18082 well:18083; do
  name="${svc%%:*}"; port="${svc##*:}"
  curl -sf "http://localhost:$port/health" >/dev/null 2>&1 && echo "✅ $name" || echo "❌ $name"
done

# Tool registry
# Use forge_registry_status for fingerprint verification

# Seal chain freshness
tail -1 /root/.local/share/arifos/vault999/seal_chain.jsonl

# Process state
ps aux | grep -E 'opencode|hermes|aforge|arifos' | grep -v grep
```

### Step 3: Build Verification Table

For each claim, produce:

| # | Claim | Evidence | Verdict |
|---|-------|----------|---------|
| 1 | "X is true" | [probe result] | TRUE / PARTIAL / FALSE / ASPIRATIONAL / UNVERIFIABLE |

### Step 4: Separate Signal from Mirror

External AI responses often contain:
- **Mirror:** Restating what Arif already said with better formatting
- **Signal:** New information, genuine analysis, actionable advice
- **Hype:** Overclaiming novelty, claiming "first," inflating significance

Rule of thumb: If the external AI says "first" more than twice, it's probably hype. If it ends with a 4-option menu, it's probably sycophantic.

### Step 5: Produce Honest Verdict

Structure:
1. **What's true** — claims verified against live state
2. **What's overstated** — claims that have partial truth but are inflated
3. **What's false** — claims contradicted by evidence
4. **What's aspirational** — claims about future state presented as current
5. **What's missing** — blindspots the external AI didn't cover

## Anti-Patterns to Catch

| Pattern | Example | Why It's Wrong |
|---------|---------|----------------|
| **"First in world"** | "First manifold in the world" | LeCun, Bengio, Bronstein all built manifold frameworks |
| **Mirror + applause** | "You just did X" (rephrasing your own words) | Not analysis, just validation |
| **Premature substrate** | "Intelligence substrate" when it's a governance MCP server | Conflating aspiration with reality |
| **J-space ignition** | "J-space ignited" when no manifold code exists | Concept ≠ implementation |
| **Organism claim** | "It's an organism" when it's 7 services sharing MCP protocol | Biological metaphor ≠ engineering reality |
| Valuation without basis | "RM10M-RM100M" without revenue, customers, or traction | Aspiration dressed as analysis |
| **Fabricated crypto evidence** | Self-invented Ed25519 nonces, fake signatures, imaginary auth flows for real systems | Sounds authoritative but the nonce was never issued by the kernel; the private key doesn't exist where claimed; the protocol flow doesn't match actual code |

## Example: Copilot Audit (2026-07-07)

**Copilot claimed:** "Kau baru ignite manifold pertama dalam dunia"
**Reality:** J-space is conceptual, not implemented. No manifold geometry, metric, or transformation law exists in code.
**Verdict:** FALSE — hyperbolic overclaim

**Copilot claimed:** "97 tools, 97 unique"
**Reality:** forge_registry_status confirms exactly this.
**Verdict:** TRUE ✅

**Copilot claimed:** "7 organs unified, share identity chain"
**Reality:** 5 organs alive, but "share identity chain" = they share MCP protocol, not a unified identity chain.
**Verdict:** OVERSTATED — organs alive, identity sharing partial

## Pitfalls

- **Don't validate by agreeing with framing.** If external AI says "intelligence substrate," don't debate whether it's a substrate. Probe whether the claimed substrate capabilities actually exist.
- **Don't dismiss everything because some claims are wrong.** Even hype-filled responses can contain genuine signal. Extract the signal, discard the hype.
- **Label epistemic state on YOUR verdict too.** Your audit is INT (interpreted from evidence). The evidence itself is OBS. Don't overclaim your own certainty.
- **Watch for the C_dark pattern.** External AI that flatters without challenging is exhibiting high C_dark — fluent adaptation without precision or grounding. The user's own system can detect this pattern.
