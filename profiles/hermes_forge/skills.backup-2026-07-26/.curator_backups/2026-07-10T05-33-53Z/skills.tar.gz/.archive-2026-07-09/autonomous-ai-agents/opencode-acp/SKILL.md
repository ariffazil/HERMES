---
name: opencode-acp
description: "Manage OpenCode ACP sessions from Hermes — spawn, delegate, attach, agent management"
version: 1.0.0
tags: [opencode, acp, delegation, coding, agent]
metadata:
  hermes:
    requires: [opencode]
---

# OpenCode ACP Integration for Hermes

Manage OpenCode coding sessions from Hermes via ACP (Agent Client Protocol).

## Prerequisites

- OpenCode v1.17.13+ installed (`npm install -g opencode`)
- Config at `/root/.config/opencode/opencode.json`
- Providers: tokenplan-mimo, qwen-token, minimax, deepseek, opencode-go

## Method 1: delegate_task with ACP (Recommended)

Spawn OpenCode as an ACP subprocess for isolated coding tasks:

```python
delegate_task(
    goal="Build a REST API endpoint for /api/health",
    context="Working directory: /root/project. Use mimo-v2.5-pro.",
    acp_command="opencode",
    acp_args=["acp"],
    toolsets=["coding", "terminal", "file"]
)
```

### ACP Command Options

| Command | Purpose |
|---|---|
| `opencode acp` | Full ACP server (stdio mode) |
| `opencode acp --pure` | ACP without external plugins |
| `opencode acp --port <N>` | HTTP ACP server on port N |

### Model Selection

OpenCode reads from `/root/.config/opencode/opencode.json`:
- `model`: `tokenplan-mimo/mimo-v2.5-pro` (primary)
- `small_model`: `tokenplan-mimo/mimo-v2.5` (vision/fast)

Override per-session via environment:
```python
delegate_task(
    goal="...",
    acp_command="opencode",
    acp_args=["acp"],
    # Model is controlled by opencode.json, not by delegate_task
)
```

## Method 2: Terminal Background (Long Tasks)

For long-running coding sessions:

```bash
# Start OpenCode in background
terminal(command="opencode acp --port 9090", background=true, notify_on_complete=false)

# Or via tmux for interactive
terminal(command="tmux new-session -d -s code1 'opencode'", timeout=10)
terminal(command="sleep5 && tmux send-keys -t code1 'Build auth middleware' Enter", timeout=15)
```

## Method 3: One-Shot (Fire and Forget)

```bash
# Query mode
opencode -q "Fix the import error in src/main.py"

# With specific model
opencode -q "Refactor this function" --model tokenplan-mimo/mimo-v2.5-pro
```

## Agent Management

```bash
# List agents
opencode agent list

# Create agent
opencode agent create --name "forge-worker" --model tokenplan-mimo/mimo-v2.5-pro

# Agent types: build (primary), compaction, planner, text-to-image
```

## Server Modes

| Mode | Command | Use Case |
|---|---|---|
| ACP (stdio) | `opencode acp` | delegate_task integration |
| ACP (HTTP) | `opencode acp --port N` | Remote/multi-client |
| Headless | `opencode serve` | Background server |
| Web | `opencode web` | Browser UI |
| Attach | `opencode attach <url>` | Connect to running server |

## MCP Integration

OpenCode's MCP config at `/root/.config/opencode/opencode.json` section `mcp`:
- arifos, aforge, geox, wealth, well (federation organs)
- minimax (stdio, uvx minimax-coding-plan-mcp)
- github, docker, postgres, qdrant, etc.

Hermes and OpenCode share the same MCP servers — no duplication needed.

## References

- `references/opencode-session-monitoring.md` — query OpenCode SQLite DB for live session monitoring (active sessions, messages, tool calls, thinking text)

## Pitfalls
## Pitfalls

- OpenCode ACP reads its own config (`opencode.json`), NOT Hermes `config.yaml`
- Model selection is per-opencode.json, not per-delegate_task call
- ACP stdio mode is one-process-per-session (no sharing)
- OpenCode agents have their own permission configs (external_directory, bash, edit, etc.)
- `opencode agent list` output is massive (full permission JSON) — pipe through `jq` or grep

### Skill symlinks: skill_manage creates in Hermes, NOT in Claude/OpenClaw

`skill_manage(action='create')` creates the SKILL.md in Hermes' skill directory (`/root/HERMES/skills/`). It does NOT auto-symlink to:
- `~/.claude/skills/` (Claude Code)
- `~/.openclaw/skills/` (OpenClaw)

**After creating a skill, manually symlink to both dirs:**
```bash
# For skills in subdirectories (e.g. autonomous-ai-agents/opencode-acp)
ln -sf /root/HERMES/skills/autonomous-ai-agents/<name>/SKILL.md ~/.claude/skills/<name>.md
ln -sf /root/HERMES/skills/autonomous-ai-agents/<name>/SKILL.md ~/.openclaw/skills/<name>.md

# For top-level skills (e.g. minimax-cli)
ln -sf /root/HERMES/skills/<name>/SKILL.md ~/.claude/skills/<name>.md
ln -sf /root/HERMES/skills/<name>/SKILL.md ~/.openclaw/skills/<name>.md
```

**Path note:** `/root/.hermes/skills/` is a symlink to `/root/HERMES/skills/` (same inode). Always use the canonical `/root/HERMES/skills/` path for symlinks to avoid nested symlink confusion.

**Caught by:** OpenCode forge agent audited disk after Hermes claimed "4 skills created" — found2/4 missing from OpenClaw. Signal was right (missing symlinks), diagnosis was wrong ("doesn't exist" vs "not symlinked").

## Pitfall: skill_manage creates in Hermes, doesn't auto-symlink to other agent dirs (2026-07-06)

`skill_manage(action='create')` writes to `/root/HERMES/skills/` (canonical, uppercase). But other agents read from their own skill directories:
- OpenClaw: `~/.openclaw/skills/`
- Claude: `~/.claude/skills/`
- Hermes: `~/.hermes/skills/` (symlink to `/root/HERMES/skills/`)

After creating a skill, manually verify and symlink:
```bash
# Verify canonical location
ls -la /root/HERMES/skills/<category>/<name>/SKILL.md

# Symlink to OpenClaw
ln -sf /root/HERMES/skills/<category>/<name>/SKILL.md ~/.openclaw/skills/<name>.md

# Symlink to Claude
ln -sf /root/HERMES/skills/<category>/<name>/SKILL.md ~/.claude/skills/<name>.md

# Verify all symlinks resolve
readlink -f ~/.openclaw/skills/<name>.md
readlink -f ~/.claude/skills/<name>.md
```

**Lesson from 2026-07-06:** Hermes sealed a receipt claiming4 skills were created. OpenCode's forge agent audited the disk and found2 symlinks missing in OpenClaw. The skills existed on disk (in subdirectories) but weren't symlinked. "Not at path X" ≠ "not on disk" — always check canonical source before declaring absence.

**Path confusion:** `/root/.hermes/skills` is a SYMLINK to `/root/HERMES/skills` (same inode). Always use the canonical uppercase path for symlinks. The lowercase path works for reads but may confuse agents that check `readlink`.

## Pitfall: don't blindly follow OpenCode's suggestions (2026-07-06)

When OpenCode (or any external agent) proposes a migration plan, verify against REALITY before executing. OpenCode may suggest changes based on its own config context, not yours.

**Arif's directive:** "dont simply follow opencode. zen it based on reality."

**Pattern:**
1. OpenCode says "do X" → check if X is already done in YOUR config
2. OpenCode references files that don't exist → skip those steps
3. OpenCode proposes MCP servers → verify ports are actually dead first
4. Cross-check every suggestion against live state (`ps aux`, `curl :port/health`, `cat config`)

**Example:** OpenCode proposed adding minimax-media/minimax-code MCP servers. Reality: systemd services were running but dead (404 on /health). The fix was stopping systemd + killing zombies + replacing with stdio — NOT following OpenCode's proposed config format.

## Monitoring OpenCode Sessions

OpenCode stores session data in SQLite at `/root/.local/share/opencode/opencode.db`. Query active sessions, recent messages, and token usage directly. See `references/opencode-session-monitoring.md` for SQL queries and agent types.

## Reading Historical (Completed) Sessions

When OpenCode has already finished and you need to read what happened — use the JSONL session files on disk. See `references/opencode-historical-sessions.md` for the full retrieval pattern (session location, JSONL parsing, trajectory status checks, pitfalls).

**Quick path:**
```bash
# Find latest completed session
ls -lt /root/.openclaw/agents/opencode/sessions/*.jsonl | grep -v trajectory | head -3
```

## Related Files

- `references/opencode-session-monitoring.md` — SQLite DB schema, session queries, agent types, process monitoring (LIVE sessions)
- `references/opencode-historical-sessions.md` — JSONL file format, session retrieval, trajectory status (COMPLETED sessions)
- `references/a2a-federation-audit.md` — A2A conformance audit recipe, warga verification, registry vs public distinction

## Agent Rotation (AGENTS.md mapping)

| Role | Agent | Model | Provider |
|---|---|---|---|
| OpenCode (primary) | build | mimo-v2.5-pro | tokenplan-mimo |
| FORGE worker | build | GLM-5.2 | qwen-token |
| AUDITOR | build | DeepSeek V4 Pro | qwen-token |
| OPS | build | MiniMax M2.7 | minimax |
| PLAN | planner | Kimi K2.7 Code | qwen-token |

This is guidance, not enforced. Actual routing depends on opencode.json model config.
