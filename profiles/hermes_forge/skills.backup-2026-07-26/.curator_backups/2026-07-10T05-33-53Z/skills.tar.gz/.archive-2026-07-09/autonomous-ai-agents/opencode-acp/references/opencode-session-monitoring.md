# OpenCode Session Monitoring via SQLite

OpenCode stores all session data in a SQLite database at `/root/.local/share/opencode/opencode.db`.

## Schema (key tables)

```sql
-- Sessions
session(id, project_id, slug, directory, title, version, 
        time_created, time_updated, time_archived,
        workspace_id, path, agent, model,
        cost, tokens_input, tokens_output, tokens_reasoning,
        tokens_cache_read, tokens_cache_write)

-- Messages (JSON data column)
message(id, session_id, time_created, time_updated, data)
-- data: {"parentID":"...","role":"assistant|user","mode":"forge","agent":"forge",
--        "cost":0.01,"tokens":{"total":221357,"input":1415,"output":214,...}}

-- Parts (tool calls, text blocks — JSON data column)
part(id, message_id, session_id, time_created, time_updated, data)
-- data examples:
-- {"type":"text","text":"..."}
-- {"type":"tool","tool":"bash","callID":"...","state":{"status":"completed","input":{"command":"..."}}}
-- {"type":"step-start"}
-- {"reason":"tool-calls","type":"step-finish","tokens":{...},"cost":...}
```

## Useful queries

```sql
-- Active (unarchived) sessions, most recent first
SELECT substr(id,1,25) as id, agent, substr(title,1,50) as title, 
       datetime(time_updated/1000,'unixepoch') as last_active,
       tokens_input, tokens_output, tokens_reasoning,
       printf('%.2f', cost) as cost_usd,
       json_extract(model,'$.id') as model,
       json_extract(model,'$.providerID') as provider
FROM session 
WHERE time_archived IS NULL
ORDER BY time_updated DESC LIMIT 5;

-- Latest tool calls in a session
SELECT datetime(time_created/1000,'unixepoch') as time,
       substr(json_extract(data,'$.tool'),1,20) as tool,
       substr(json_extract(data,'$.state.input.command'),1,100) as command
FROM part
WHERE session_id LIKE 'ses_PREFIX%'
AND json_extract(data,'$.type') = 'tool'
ORDER BY time_created DESC LIMIT 5;

-- Latest thinking/text in a session
SELECT substr(json_extract(data,'$.text'),1,300) as thinking
FROM part
WHERE session_id LIKE 'ses_PREFIX%'
AND json_extract(data,'$.type') = 'text'
AND json_extract(data,'$.text') != ''
ORDER BY time_created DESC LIMIT 3;

-- Message count and token totals for a session
SELECT COUNT(*) as messages, 
       SUM(json_extract(data,'$.tokens.total')) as total_tokens
FROM message WHERE session_id LIKE 'ses_PREFIX%';
```

## Pitfalls

- Timestamps are milliseconds since epoch (divide by 1000 for unix epoch)
- `data` column is JSON — use `json_extract()` for field access
- `part.data.type` can be: text, tool, step-start, step-finish
- `opencode agent list` dumps FULL permission JSON (massive output) — pipe through `grep -E '^\w'` for just agent names
- Process monitoring: `ps aux | grep opencode` shows active sessions (look for high CPU %)
- Web UI at `http://127.0.0.1:<port>/` returns HTML, not JSON API
