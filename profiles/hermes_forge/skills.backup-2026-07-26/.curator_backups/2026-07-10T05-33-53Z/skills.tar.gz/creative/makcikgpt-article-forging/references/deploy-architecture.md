# arif-fazil.com Deploy Architecture

## Two Deploy Paths

| Site | Deploy Method | Server |
|------|--------------|--------|
| `arif-fazil.com` (main + /wealth/makcikgpt/) | **Cloudflare Pages** — auto-deploy on `git push origin main` | Cloudflare CDN |
| `aaa.arif-fazil.com`, `arifos.arif-fazil.com`, `geox.arif-fazil.com` etc | **VPS Caddy** — `deploy-vps.sh` or `scripts/deploy-site.sh` | VPS (Docker + Caddy) |

## MakcikGPT lives on Cloudflare Pages

The MakcikGPT articles are part of the main arif-fazil.com React site. They deploy via Cloudflare Pages, NOT VPS Caddy.

- Source: `/root/arif-sites/sites/arif-fazil.com/src/data/makcikgpt/`
- Build: `npm run build` in `/root/arif-sites/sites/arif-fazil.com/`
- Deploy: `git push origin main` from `/root/arif-sites/`
- Propagation: ~2 minutes

## VPS Deploy Script Issues (as of 2026-07-06)

`deploy-vps.sh` calls `scripts/deploy-site.sh` which runs `npm ci` and fails with peer-dependency conflicts. The build step works fine standalone (`npm run build`), but the deploy script's npm ci step breaks. Use git push for Cloudflare Pages sites instead.

## Caddy serves these (NOT Cloudflare):
- /var/www/html/arifos → arifos.arif-fazil.com
- /var/www/html/geox → geox.arif-fazil.com
- /var/www/html/arif → (some static assets)
