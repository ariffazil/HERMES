---
name: makcikgpt-article-forging
description: "Forge MakcikGPT articles for arif-fazil.com — research-driven, MakcikGPT voice, TypeScript format, deploy to VPS. Covers the full pipeline: OBSERVE (research) → HYPOTHESIZE (angle) → FORGE (write) → VERIFY (build) → DEPLOY."
triggers:
  - "makcikgpt article"
  - "write makcikgpt"
  - "forge makcikgpt"
  - "publish makcikgpt"
  - "makcikgpt pasal"
  - "cerita makcik"
version: "1.0"
---

# MakcikGPT Article Forging — v1.0

> Strip jargon. Tanya "niat siapa?". Connect institutional decay to individual survival moves.

---

## What This Is

A repeatable pipeline for forging MakcikGPT articles on arif-fazil.com.
MakcikGPT is Arif's publication voice — the makcik who sees through corporate/political language and asks the human question underneath.

---

## Pipeline: 5 Stages

| Stage | What | Tools |
|-------|------|-------|
| **1. OBSERVE** | Multi-source research on the topic | forge_search, web_extract, wealth/well/geox tools |
| **2. HYPOTHESIZE** | Find the hidden thread connecting disparate data | LLM reasoning |
| **3. FORGE** | Write article in MakcikGPT voice + TypeScript format | write_file |
| **4. VERIFY** | Build site, check for errors | npm run build |
| **5. DEPLOY** | Push to VPS | deploy-vps.sh |

---

## Stage 1: OBSERVE — Research

**Rule: 3+ searches minimum. Breadth before depth.**

For multi-domain articles (economy + politics + social + tech), see [multi-domain-research-pattern.md](references/multi-domain-research-pattern.md) for the parallel-search-sequential-synthesize pattern with proven source list.

Search strategy:
- Surface data (what happened)
- Structural data (why it matters)
- Shadow data (who benefits, who loses)

Use `forge_search` or `web_search` for breadth. Use `web_extract` or `forge_fetch` for depth on specific articles.

**Evidence tagging:** Every data point gets OBS/DER/INT/SPEC tag. MakcikGPT articles always declare epistemic state.

---

## Stage 2: HYPOTHESIZE — Find the Thread

**Rule: One hidden thread connecting all data. Not multiple disconnected points.**

Ask:
- "Apa benang yang sama?" (What's the common thread?)
- "Siapa yang untung?" (Who benefits?)
- "Apa yang tak dibicarakan?" (What's not being discussed?)
- "Niat siapa di sebalik ni?" (Whose intention is behind this?)

The thread is the article's thesis. Without it, the article is just a news summary.

---

## Stage 3: FORGE — Write

### MakcikGPT Voice Rules

1. **BM Penang casual** — "hang", "depaa", "kat", "kena", "tak", "ni", "tu"
2. **Strip jargon** — if a corporate/political term appears, translate it to human language
3. **Ask the shadow question** — "niat siapa yang sebenar?"
4. **Connect institutional to personal** — how does this policy/event affect the makcik at the pasar?
5. **No false balance** — Makcik has a view, but shows evidence
6. **Declare epistemic state** — OBS/INT/SPEC/SHADOW at the top
7. **End with questions, not answers** — Makcik provokes, doesn't prescribe

### Voice Anti-Patterns (NEVER do these)

- ❌ Corporate summary tone ("The government announced...")
- ❌ Academic neutrality ("Both sides have valid points...")
- ❌ AI-isms ("It's important to note...", "In conclusion...")
- ❌ English paragraphs mixed in (use BM for body, English only for quotes/data)
- ❌ Formatting like a report (no bullet-point dump — use narrative)

### Article Structure (HTML Sections)

```
<div class="cover">
  cover-emoji, cover-kicker, cover-title, cover-subtitle, cover-byline
</div>

<h1>Title (repeat)</h1>
<p><strong>Epistemic:</strong> OBS/INT/SPEC/SHADOW declaration</p>
<hr />

<h2>Δ GROUND — Apa yang betul-betul berlaku</h2>
  Surface facts. Data. Numbers. What happened.

<h2>Ω MIND — Apa yang sebenarnya berlaku di dalam</h2>
  Hidden thread. Pattern recognition. "Bukan pasal X. Pasal Y."

<h2>Ξ CAPITAL — Apa makna untuk duit</h2>
  Economic/financial implications for rakyat.

<h2>Ψ SOVEREIGN — Kenapa ini penting</h2>
  Why this matters for human dignity, sovereignty, future.

<h2>Calhoun Universe 25 & Acemoglu Extractive</h2>
  (Optional) Institutional decay pattern analysis.

<h2>Kenapa Manusia "Jadi Evil"?</h2>
  (Optional) The human motivation behind institutional failure.

<h2>Cedu yang Tak Ada Nama (Moral Injury)</h2>
  (Optional) The unnamed moral injury at the heart of the story.

<h2>Apa Makcik Nampak</h2>
  Summary. Final questions. "Makcik tak ada penyelesaian. Makcik cuma ada soalan."

<p><strong>DITEMPA BUKAN DIBERI — MakcikGPT bersuara untuk rakyat.</strong></p>
<p><em>Nota: Source attribution + epistemic disclaimer</em></p>
```

---

## Stage 4: VERIFY — Build

```bash
cd /root/arif-sites/sites/arif-fazil.com
npm run build
```

If build fails, check:
- TypeScript syntax in the new .ts file
- Import statement in index.ts
- Metadata shape matches `MakcikArticleMeta` interface

---

## Stage 5: DEPLOY

**Primary deploy: Cloudflare Pages (auto-deploy on push).**

```bash
cd /root/arif-sites
git add sites/arif-fazil.com/src/data/makcikgpt/<article>.ts sites/arif-fazil.com/src/data/makcikgpt/index.ts
git commit -m "makcikgpt: <title> (<date>)"
git push origin main    # NOT "git push main" — that fails (interprets 'main' as remote name)
```

Cloudflare Pages auto-builds from `main` branch. ~2 min propagation.

**VPS deploy (direct):** `bash deploy-vps.sh` — syncs dist to Caddy, reloads proxy. Works as of 2026-07-06. Immediate, no git push needed.

Verify: `curl -sf "https://arif-fazil.com/wealth/makcikgpt/" | grep "slug-name"`

**Pitfall: `git push main` ≠ `git push origin main`.** The first interprets `main` as a remote name and fails with "does not appear to be a git repository." Always use `git push origin main`.

---

## File Locations

| What | Path |
|------|------|
| Article .ts files | `/root/arif-sites/sites/arif-fazil.com/src/data/makcikgpt/` |
| Index + metadata | `/root/arif-sites/sites/arif-fazil.com/src/data/makcikgpt/index.ts` |
| Types | `/root/arif-sites/sites/arif-fazil.com/src/data/makcikgpt/types.ts` |
| Site root | `/root/arif-sites/sites/arif-fazil.com/` |
| Deploy script | `/root/arif-sites/deploy-vps.sh` |

---

## TypeScript Template

```typescript
import type { ArticleContent } from './types';

const content: ArticleContent = {
  slug: 'article-slug-here',
  html: `<div class="cover">
<p class="cover-emoji">🇲🇾 [EMOJI] 🇲🇾</p>
<p class="cover-kicker">Cerita untuk Jiran-Jiran</p>
<h1 class="cover-title">Title Here</h1>
<p class="cover-subtitle">Subtitle here</p>
<div class="cover-byline">
<strong>Oleh MakcikGPT</strong> — suara yang tanya "niat siapa yang sebenar?"<br>
999 Meterai · [DD] [Month] [YYYY]
</div>
</div>

[Article body with Δ Ω Ξ Ψ sections]
`,
};

export default content;
```

---

## Pitfalls

1. **Don't write without research.** Minimum 3 searches before writing. MakcikGPT is data-driven, not opinion-driven.
2. **Don't use English in body.** BM only. English for direct quotes, data values, and proper nouns.
3. **Don't summarize news.** MakcikGPT finds the HIDDEN THREAD. If the article reads like a news summary, rewrite.
4. **Don't forget to register in index.ts.** Both the import AND the makcikArticlesMeta entry.
5. **Don't skip the build.** Always verify with `npm run build` before deploying.
6. **Don't deploy without verifying.** Check the built site loads the new article.
7. **Don't use the cover-title for the slug.** Slug should be kebab-case English, title can be BM.
8. **Don't omit the epistemic declaration.** Every article starts with OBS/INT/SPEC/SHADOW.
9. **VPS deploy via `deploy-vps.sh` works (verified 2026-07-06).** If npm ci fails with peer-dependency errors, the VPS deploy script handles it separately. Both `deploy-vps.sh` and `git push origin main` are valid deploy paths. VPS is immediate; Cloudflare has ~2 min propagation.
10. **Don't use parallel subagents for the research stage without summarizing first.** Delegate 3 parallel research tasks (macro data, political dynamics, structural challenges), wait for all 3, THEN synthesize into the article. Don't try to write while research is still running.
