---
name: scientific-pdf-generation
description: "Generate publication-quality scientific PDFs with reportlab + matplotlib — white backgrounds for academic papers, dark-themed variants for intelligence dossiers. Serif fonts, two-column layout, proper typography, figure styling, references."
triggers:
  - "scientific pdf"
  - "publication quality document"
  - "academic paper pdf"
  - "geology report pdf"
  - "research paper"
  - "synthesis document"
---

# Scientific PDF Generation

## When to Use

When producing documents meant to look like real scientific publications — journal papers, technical reports, synthesis documents. 

**Two modes:** Mode A (academic, white background) is the default. Mode B (dark-themed intelligence dossier) is for field-ready briefings and professional impression documents. Choose based on audience.

## Mode A: Academic / Publication (Default)

**White background, serif fonts, muted colors.** For journal papers, technical reports, formal deliverables.

## Stack

Three rendering paths — choose based on document type:

| Path | Best for | Speed | Setup |
|------|----------|-------|-------|
| **pandoc→xelatex** | Text-heavy docs with tables, TOC, cross-refs | Fast (seconds) | pandoc + texlive-xetex |
| **weasyprint** | HTML-driven layout, CSS-styled, figures embedded | Medium | pip install weasyprint |
| **reportlab** | Programmatic control (headers/footers/page templates) | Slow (coding) | pip install reportlab |

### Path 1: pandoc→xelatex (FASTEST for text-heavy scientific documents)

Use when the document is primarily text + tables + references and you need a professional PDF fast.

```bash
pandoc input.md -o output.pdf \
  --pdf-engine=xelatex \
  -V geometry:margin=1in \
  -V fontsize=11pt \
  -V mainfont="DejaVu Serif" \
  -V monofont="DejaVu Sans Mono" \
  -V colorlinks=true \
  -V linkcolor=blue \
  --toc \
  --toc-depth=3 \
  -V toc-title="Contents"
```

**Proven:** 2026-07-05, APEX Theory Review v2 (24 pages, 15 tables, 45 references). Rendered in <5 seconds.

**Key flags:**
- `--pdf-engine=xelatex` — supports Unicode, system fonts, complex tables
- `--toc` — auto-generates table of contents from markdown headers
- `-V mainfont="DejaVu Serif"` — serif body text (check `fc-list | grep -i serif` for available fonts)
- `-V geometry:margin=1in` — standard academic margins

**Pitfalls:**
- If xelatex is not installed: `apt install texlive-xetex` (or `texlive-latex-recommended` for pdflatex)
- Wide tables may overflow — use `pandoc -V geometry:margin=0.8in` or restructure as lists
- Unicode math symbols (`×`, `→`, `≥`) render correctly with xelatex but may fail with pdflatex

### Path 2: weasyprint (HTML→PDF)

Use when you need CSS-driven layout (two-column, colored boxes, inline images).

```python
from weasyprint import HTML
HTML(filename='manuscript.html', base_url='/tmp/figures/').write_pdf('output.pdf')
```

### Path 3: reportlab (programmatic)

Use when you need canvas-level control (running headers, page templates, dynamic content).

- **reportlab** — PDF assembly (platypus flow: paragraphs, images, tables, page templates)
- **matplotlib** — figure generation (set `figure.facecolor: white`, `font.family: serif`)

## Mode B: Intelligence Dossier / Field-Ready

**Dark background, gold/amber accents, sans-serif headers.** For intelligence briefings, field dossiers, modern technical presentations, documents meant to impress in professional settings.

Use Mode B when:
- Document is an intelligence briefing, competitive intel, or domain dossier
- Audience is a working professional (geologist, engineer, executive) in a field/social setting
- The dark theme signals modernity and technical sophistication
- Arif says "dossier", "briefing", "impress", or "wow"

### Mode B Color Palette
```
Background:  #0d1117 (GitHub dark)
Panel:       #161b22 (slightly lighter, for header/footer bars)
Gold accent: #f0a500 (headlines, section markers, accent lines)
Amber:       #ffa657 (subheadings, secondary emphasis)
Green:       #3fb950 (positive signals, key findings)
Blue:        #58a6ff (info, data points, figures)
Red:         #f85149 (warnings, critical signals, risk flags)
Teal:        #39d2c0 (conversation starters, quotes)
Text:        #e6edf3 (body — near-white, NOT pure white)
Dim:         #8b949e (captions, references, footer text)
Border:      #30363d (table grid lines, separators)
```

### Mode B Typography
```
Body:        Helvetica, 10pt, #e6edf3, JUSTIFY
Headings:    Helvetica-Bold, 18pt H1 (#f0a500) / 14pt H2 (#ffa657) / 11pt H3 (#3fb950)
Tables:      Alternating row backgrounds (#161b22 / #1a1f28), header row #1a2332
Captions:    Helvetica-Oblique, 8pt, #8b949e, center-aligned
Quotes:      Helvetica-Oblique, 10pt, #ffa657, gold border, dark panel background
```

### Mode B Page Template (reportlab BaseDocTemplate)

```python
def draw_background(canvas, doc):
    canvas.saveState()
    # Dark background
    canvas.setFillColor(HexColor('#0d1117'))
    canvas.rect(0, 0, A4[0], A4[1], fill=1, stroke=0)
    # Header bar
    canvas.setFillColor(HexColor('#161b22'))
    canvas.rect(0, A4[1] - 12*mm, A4[0], 12*mm, fill=1, stroke=0)
    # Gold accent line
    canvas.setStrokeColor(HexColor('#f0a500'))
    canvas.setLineWidth(1.5)
    canvas.line(0, A4[1] - 12*mm, A4[0], A4[1] - 12*mm)
    # Header text (title left, classification right)
    canvas.setFont('Helvetica-Bold', 8)
    canvas.setFillColor(HexColor('#f0a500'))
    canvas.drawString(2*cm, A4[1] - 9*mm, 'DOCUMENT TITLE')
    canvas.setFont('Helvetica', 7)
    canvas.setFillColor(HexColor('#8b949e'))
    canvas.drawRightString(A4[0] - 2*cm, A4[1] - 9*mm, 'CONFIDENTIAL')
    # Footer bar
    canvas.setFillColor(HexColor('#161b22'))
    canvas.rect(0, 0, A4[0], 10*mm, fill=1, stroke=0)
    canvas.setStrokeColor(HexColor('#f0a500'))
    canvas.setLineWidth(0.5)
    canvas.line(0, 10*mm, A4[0], 10*mm)
    canvas.setFont('Helvetica', 7)
    canvas.setFillColor(HexColor('#8b949e'))
    canvas.drawString(2*cm, 4*mm, 'Source attribution')
    canvas.drawRightString(A4[0] - 2*cm, 4*mm, f'Page {doc.page}')
    canvas.restoreState()
```

### Mode B Matplotlib Figure Defaults
```python
plt.rcParams.update({
    'figure.facecolor': '#0d1117',
    'axes.facecolor': '#0d1117',
    'text.color': '#e6edf3',
    'axes.labelcolor': '#e6edf3',
    'xtick.color': '#8b949e',
    'ytick.color': '#8b949e',
    'axes.edgecolor': '#30363d',
    'grid.color': '#21262d',
    'font.family': 'DejaVu Sans',
    'font.size': 10,
})
```

Use accent colors (#f0a500 for highlights, #3fb950 for positive, #f85149 for risk) in figures. Use `matplotlib.patheffects.withStroke(linewidth=3, foreground='#0d1117')` for text labels that need to be readable over colored fills.

### Mode B Document Structure (Intelligence Dossier)

1. **Cover page** — title (large, gold), subtitle (amber), prepared-for line, date, description of contents, key references
2. **Table of contents** — numbered sections with dim text
3. **Numbered sections** — each with H1 (gold) + H2 (amber) + body + figures + tables
4. **Conversation starters** — in teal-bordered boxes with dark green background (#0d1f0d)
5. **References** — numbered, dim text, hanging indent
6. **Disclaimer** — center-aligned, dim, gold rule above

**Proven:** 2026-07-07 — Block P Deepwater Sabah Geological Dossier (10 pages, 6 figures, 946 KB). Dark theme with gold accents. Delivered as professional intelligence document.

## Style Defaults (Mode A — apply unless user overrides or Mode B selected)

### Typography
```
Body:        serif (Times-Roman / Liberation Serif), 10pt, 14pt leading, JUSTIFY
Headings:    sans-serif (Helvetica-Bold), 13pt section / 11pt subsection
Captions:    serif, 9pt, italic, dark gray (#666666)
References:  serif, 9pt, hanging indent (leftIndent=1cm, firstLineIndent=-1cm)
```

### Colors
```
Text:        #1a1a1a (near-black, NOT pure black)
Accent:      #2c5f8a (muted blue) for section heads, NOT neon
Epistemic:   OBS=#2e7d32, INT=#e65100, SPEC=#6a1b9a (muted, distinguishable)
Rules:       #cccccc (light gray)
Background:  white (#ffffff)
```

### Layout
```
Page:        A4
Margins:     2.5cm sides, 3.0cm top, 2.5cm bottom
Columns:     Two-column for body text (col_width = (text_width - gap) / 2)
Header:      Running header with document title + year, thin rule below
Footer:      Centered page number (— N —), thin rule above
```

### Figures (matplotlib)
```
facecolor:   white (#ffffff) or #fafafa
font:        serif (DejaVu Serif / Liberation Serif)
edgecolor:   #666666
grid:        #cccccc, alpha=0.3
colors:      Muted palette — #2c5f8a, #8b2500, #2e7d32, #e65100, #6a1b9a, #00695c
markers:     edgecolors="black", markeredgewidth=0.8
legend:      framealpha=0.9, edgecolor="#cccccc"
dpi:         200
```

## Document Structure (standard)

1. **Title page** — title, subtitle, author/org, date, epistemic band table, provenance note
2. **Abstract** — centered label, indented body (2cm L/R), keywords line
3. **Numbered sections** — 1. Introduction, 2–N body, Conclusions, References
4. **Figures** — full-width (15.5cm), caption with bold "Figure N." + epistemic label in italics
5. **References** — hanging indent, journal names in italics
6. **Provenance table** — source, type, epistemic label

## Two-Column Pattern (reportlab)

```python
from reportlab.platypus import Table, TableStyle

col_gap = 0.5 * cm
col_width = (text_width - col_gap) / 2
t = Table([[left_paras, right_paras]], colWidths=[col_width, col_width])
t.setStyle(TableStyle([
    ("VALIGN", (0,0), (-1,-1), "TOP"),
    ("LEFTPADDING", (0,0), (0,0), 0),
    ("LEFTPADDING", (1,0), (1,0), col_gap),
    ("RIGHTPADDING", (0,0), (-1,-1), 0),
    ("TOPPADDING", (0,0), (-1,-1), 0),
    ("BOTTOMPADDING", (0,0), (-1,-1), 0),
]))
```

## Page Template Pattern (reportlab)

Use `BaseDocTemplate` with two `PageTemplate`s:
- `TitlePage` — minimal footer only
- `ContentPage` — running header + footer via `onPage` callback

```python
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, NextPageTemplate

def header_footer(canvas, doc):
    canvas.saveState()
    # header rule + text
    canvas.setStrokeColor(RULE_GRAY)
    canvas.setLineWidth(0.5)
    canvas.line(margin_left, page_h - margin_top + 0.8*cm, ...)
    canvas.setFont("Times-Italic", 8)
    canvas.drawString(margin_left, ..., "Document Title")
    # footer
    canvas.drawCentredString(page_w/2, margin_bottom - 1.0*cm, f"— {doc.page} —")
    canvas.restoreState()

doc = BaseDocTemplate(...)
doc.addPageTemplates([
    PageTemplate(id="TitlePage", frames=[...], onPage=title_footer),
    PageTemplate(id="ContentPage", frames=[...], onPage=header_footer),
])
# In story: NextPageTemplate("ContentPage") before first PageBreak
```

## Pitfalls

- **Dark theme is for intelligence dossiers only.** For academic/publication work, start with white. Use dark theme (Mode B) ONLY when the document is an intelligence briefing, field dossier, or professional impression piece. If unsure, default to white.
- **Monospace fonts look like code.** Use serif for body (Mode A), sans-serif for body (Mode B — Helvetica works well on dark).
- **Unicode symbols may not render.** Use "P"/"R"/"K" for PASS/REVIEW/KILL in kill matrices instead of ✓/?/✗ — DejaVu Serif may lack these glyphs.
- **Font availability varies.** Always check `fc-list | grep -i serif` before assuming Times-Roman exists. Fallback chain: Times-Roman → DejaVu Serif → Liberation Serif → Helvetica.
- **reportlab Image() needs absolute paths.** Use `str(OUT_DIR / "fig.png")`, not relative.
- **Media delivery directory restrictions.** OpenClaw message tool restricts `media=` to allowed directories. If `/root/forge_work/` is blocked, copy to `/var/arifos/artifacts/outbox/` or use direct Bot API (`curl -X POST .../sendDocument`).
- **DejaVu Serif registration required for reportlab.** reportlab does NOT recognize "DejaVu Serif" (with space) as a built-in font. You must register TTF files explicitly before using them:
  ```python
  from reportlab.pdfbase import pdfmetrics
  from reportlab.pdfbase.ttfonts import TTFont
  pdfmetrics.registerFont(TTFont('DejaVuSerif', '/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'))
  pdfmetrics.registerFont(TTFont('DejaVuSerif-Bold', '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'))
  pdfmetrics.registerFont(TTFont('DejaVuSerif-Italic', '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Italic.ttf'))
  pdfmetrics.registerFont(TTFont('DejaVuSerif-BoldItalic', '/usr/share/fonts/truetype/dejavu/DejaVuSerif-BoldItalic.ttf'))
  pdfmetrics.registerFontFamily('DejaVuSerif', normal='DejaVuSerif', bold='DejaVuSerif-Bold',
      italic='DejaVuSerif-Italic', boldItalic='DejaVuSerif-BoldItalic')
  ```
  Then use font names WITHOUT spaces in styles: `SERIF = "DejaVuSerif"`, `SERIF_B = "DejaVuSerif-Bold"`, `SERIF_I = "DejaVuSerif-Italic"`. Using "DejaVu Serif" (with space) causes `ValueError: Can't map determine family/bold/italic for dejavu serif`. The `serif` in the error refers to reportlab trying to parse the font family and failing because it's not a registered PostScript name. Path proven 2026-07-07.
- **TableStyle TEXTCOLOR per-row requires separate commands.** You cannot pass a list of colors to a single TEXTCOLOR command for different rows. This crashes with `AssertionError` in `colors.toColor`. Use one command per row:
  ```python
  # WRONG — crashes:
  ('TEXTCOLOR', (0, 1), (0, -1), [green, amber, purple])
  # RIGHT — one command per row:
  ('TEXTCOLOR', (0, 1), (0, 1), green),
  ('TEXTCOLOR', (0, 2), (0, 2), amber),
  ('TEXTCOLOR', (0, 3), (0, 3), purple),
  ```
  Proven 2026-07-07.
- **`ax.broken_barh` does NOT accept a `(color, hatch_string)` tuple in `facecolors`.** It crashes with `ValueError: Invalid RGBA argument: '//'` because matplotlib tries to interpret the second tuple element as an RGBA value. Workaround: use `ax.barh()` with `hatch='//'` (hatch is a separate kwarg, not part of facecolors). Proven 2026-07-09, MBR 2026 GEOX bid proposal — broken_barh pattern was replaced with barh pattern in the Miocene tectonic timeline figure.
  ```python
  # WRONG — crashes:
  ax.broken_barh([(-33, 5)], (0.5, 0.4),
                 facecolors=('#c49a5a', '//'), edgecolor='#8a6828')
  # RIGHT — hatch is separate:
  ax.barh(0.7, 5, left=-33, height=0.4,
          color='#c49a5a', hatch='//', edgecolor='#8a6828')
  ```
- **PYROLITE.MPLSTYLE warning is cosmetic, not fatal.** Every matplotlib call prints `Bad key legend.bbox_to_anchor in file /root/.config/matplotlib/stylelib/pyrolite.mplstyle, line 27 ('legend.bbox_to_anchor : (1, 1)')` followed by a "you probably need to get an updated matplotlibrc" message. Ignore — figures still render correctly. Don't waste time fixing it. The warning is from a third-party style file (pyrolite, a geochemistry library) that pre-dates matplotlib 3.11.
- **`mplstyle` warnings can be silenced if the noise is annoying in CI logs.** Set `MPLCONFIGDIR=/tmp/.mpl` before importing matplotlib to isolate config to a clean directory, or explicitly call `plt.style.use('default')` before the user rcParams. The cleaner fix is to delete or rename the offending file at `/root/.config/matplotlib/stylelib/pyrolite.mplstyle` — but this is shared state, only do it if you control the box.
- **`execute_code` sandbox does NOT have matplotlib** even when system `python3` does. The hermes_tools sandbox uses a different venv from `/usr/bin/python3`. Symptom: `ModuleNotFoundError: No module named 'matplotlib'`. Fix: switch the entire script to a terminal `python3` invocation with `MPLCONFIGDIR` set, instead of using the `execute_code` tool. Proven 2026-07-09, MBR 2026 figure generation — the sandbox import failed, then ran fine via `terminal(command="python3 -c '...'")`.

## Proven: Multi-Figure Weasyprint Pipeline (12 figures, single PDF)

For deliverables with many embedded figures (10+), this pipeline is faster and more reliable than reportlab. **Proven 2026-07-09, MBR 2026 GEOX bid proposal: 12 figures, 2.9 MB, ~5 sec render.**

### Step 1 — Generate figures as PNGs to a single directory
```python
import os
os.environ['MPLCONFIGDIR'] = '/tmp/.mpl'  # silence pyrolite warning
import matplotlib
matplotlib.use('Agg')  # no display
import matplotlib.pyplot as plt

OUT = Path('/tmp/mbr2026_figures')
OUT.mkdir(exist_ok=True)
# ... generate fig1.png, fig2.png, ... fig12.png at 200 dpi
plt.savefig(OUT / 'figN_name.png', dpi=200, facecolor='white')
```

### Step 2 — Write HTML manuscript with `<img src="figN.png">` references
All figures live in the same directory as the HTML. Inline CSS for academic style — see `templates/weasyprint_manuscript.html` (path proven 2026-07-09, MBR 2026).

### Step 3 — Convert to PDF
```bash
cd /tmp/mbr2026_figures
weasyprint manuscript.html MBR2026-GEOX-ARTIFACTS.pdf 2>&1
ls -la MBR2026-GEOX-ARTIFACTS.pdf
```

**Key flags:** none required. The default `weasyprint html output.pdf` works. `base_url` only matters when HTML is in a different directory than the figures — if they're co-located, no `base_url` needed.

### Step 4 — Deliver via artifact-courier.sh
```bash
bash /root/.hermes/scripts/artifact-courier.sh \
  /var/arifos/artifacts/outbox/$(date +%Y-%m-%d)/MBR2026-GEOX-ARTIFACTS.pdf \
  --caption "MBR2026 GEOX Geological Artifacts — 12 figures: ..."
```

Returns SHA256 receipt + Telegram message_id. The courier handles: source retention (F1 AMANAH), hash governance (F2 TRUTH), audit log (F11 AUDIT), F13 SOVEREIGN routing to ARIF chat only.

### Pitfall: weasyprint ignores `box-shadow`
`box-shadow: 0 2px 4px rgba(0,0,0,0.1)` is silently dropped. Harmless warning. Don't fix.

### Pitfall: `padding-top: 15vh` invalid value
weasyprint rejects `vh` units in some contexts. Use `padding-top: 200px` or omit. Harmless warning, but figure it out before treating the warning as no-op.

## Verification

After generating:
1. Check file size (should be 500KB–2MB for 8 figures)
2. Open in PDF viewer — white background, serif fonts, proper margins
3. Check page count matches expectations
4. Verify figure captions are present and properly formatted

## References

- `templates/scientific_report.py` — minimal scaffold: title page, abstract, sections, figures, references. Copy and modify.
- `templates/geological_dossier.py` — domain intelligence report scaffold with reportlab + matplotlib, DejaVu font registration, info tables, callout boxes, epistemic bands. Proven 2026-07-07.
- `references/figure-white-theme-patterns.md` — matplotlib white-theme rcParams, muted color palette, figure patterns (tectonic map, cross-section, cooling path, kill matrix), Unicode glyph pitfalls.
- `references/geological-dossier-figures.md` — 5 reusable matplotlib figure patterns for geological intelligence dossiers: regional map, stratigraphic column, timeline, play types, hub-and-spoke strategy.
- `references/tectono-stratigraphic-panels.md` — multi-column × multi-row geological evolution diagrams: grid layout, color semantics for lithologies, polygon fills, process arrows, depth panels. Proven 2026-07-07 (NSPW mud canopy evolution, 5 stages × 3 panels).
- `references/deepwater-sabah-geology.md` — domain reference bank: verified PSC blocks, three toe-thrust trends, NSPW mud canopy, crustal architecture, PTTEP competitive intelligence, reservoir architecture, petroleum system risks, bilingual talking points, coordinate verification protocol. Use when generating geological dossiers for NW Sabah.
- `references/geological-artifact-figures.md` — reusable matplotlib patterns for **geological deliverable figures**: well correlation panels, 5-track petrophysical log panels, structural cross-sections with trap analysis, well penetration summaries, play fairway thickness maps. Proven 2026-07-09, MBR 2026 GEOX bid proposal.
