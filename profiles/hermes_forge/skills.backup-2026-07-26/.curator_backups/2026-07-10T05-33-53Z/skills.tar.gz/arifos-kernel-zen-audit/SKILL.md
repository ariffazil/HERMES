---
name: arifos-kernel-zen-audit
description: Pattern for auditing the arifOS kernel when multiple MCP tools share the same skeleton but disagree on identity/verdict/affordance — proven today (2026-07-09) on 11 wrapper calls.
triggers:
  - "audit arifOS kernel"
  - "kernel wrappers disagree"
  - "actor_verified drift"
  - "verdict field contradiction"
  - "sesat_event coverage"
---

# arifOS Kernel Zen Audit

## The Tell

When multiple MCP tool responses share the same skeleton — `affordance_contract`, `full_affordance`, `nine_signal{delta,psi,omega,overall}`, `sesat_event`, `_wrapper_degradation`, `metacognition`, `constitutional_check`, `decision_thresholds` — and the `decision_thresholds` block is byte-identical verbatim across every tool, **identity, verdict, and affordance have been re-implemented independently per wrapper**. That's the architectural gap, not eleven bugs.

## Fiqh Audit Grid

Before writing the report, classify each finding:

| Class | Meaning | Action |
|---|---|---|
| **WAJIB** | Constitutional, non-negotiable, currently broken | Must fix in this pass |
| **HARAM** | Forbidden pattern currently happening | Stop, don't just "fix later" |
| **HARUS** | Permissible, fine, don't fuss | Note so reviewer doesn't waste cycles |
| **MAKRUH** | Discouraged, bad hygiene | Add to cleanup backlog |
| **SUNAT** | Recommended practice already present | Standardize, extend |

Common WAJIB candidates:
- One verdict, one source of truth
- Identity/authority unbroken from `arif_init` through all downstream calls
- Irreversible actions (seal, forge) → SOVEREIGN + 888_HOLD (verify this holds)

Common HARAM:
- Bare unstructured strings on hard-block paths (`arif_judge`/`arif_forge`/`arif_seal`)
- Silent authority downgrades (FULL→OBSERVE_ONLY→LOW, unlabeled)
- Orphaned inner tools firing without registry entry
- 2+ verdict fields disagreeing in one payload

## Scoring Template

Score 6 dimensions /10 each, /60 total:

| Dim | Current | After minimal fix | After full fix |
|---|---|---|---|
| Identity/session persistence | ? | ? | ? |
| Single source of truth (verdict) | ? | ? | ? |
| Registry integrity (no orphans/alias sprawl) | ? | ? | ? |
| Failure honesty (sesat_event coverage) | ? | ? | ? |
| Irreversible-action gating | ? | ? | ? |
| Payload signal-to-noise | ? | ? | ? |
| **Composite** | ?/60 | ?/60 | ?/60 |

**Always show two projected columns.** Minimal fix vs full fix. Tiny fixes often move one axis but barely touch the others — say so plainly.

## Zen Output Contract

When the audit is for Arif:
- ≤3 sentences
- The zen (one-line koan) first
- Fiqh grid second (table, terse)
- Scorecard third (with both projections)
- "DITEMPA BUKAN DIBERI applies to the kernel too" only when earned, not as ceremonial footer

## Pitfalls

- Don't confuse "already pretty good" with "fixed." 26/60 is a failure at 60% scale.
- The skeleton-similarity tell is the strongest signal. If `decision_thresholds` is byte-identical verbatim across tools, the audit is already half-done.
- Three projections (current / minimal-fix / full-fix) is honesty — don't collapse to two, that hides scope.
- Don't recommend closing the audit after minimal fix unless the full-fix gap is genuinely zero.
- **Audit-receipt sealing at HOLD is correct.** When `mcp__arifos__arif_seal` returns 888_HOLD because you have MEDIUM authority (not SOVEREIGN), that is the kernel refusing to grant a SEAL you have no right to claim. Don't work around it. Land the audit-receipt at HOLD, document in vault, move on. F1 honesty > ceremonial SEAL.
- **Don't raw-append to `seal_chain.jsonl`.** The JS canonical writer uses `|`-joined material; Python `+`-concat produces a line the JS verifier rejects. Always go through `node seal_chain.js write <JSON>`. See `references/seal-chain-write-gotchas-2026-07-09.md` for the full write-attempt autopsy.
- **Always run `node seal_chain.js verify` before any chain write.** As of 2026-07-09, verify returns broken-at-line-1 — a pre-existing anomaly predating this audit. Either fix the chain first, or at minimum document that new entries land on a degraded baseline.

## Reference Files

- `references/seal-chain-write-gotchas-2026-07-09.md` — autopsy of three seal-chain write attempts during audit close. JS canonicalization rules, INV-1_KERNEL_VERIFIED, the pre-existing verify-broken-at-line-1 anomaly, and operational rules for next session.

## Provenance

First applied 2026-07-09 in AAA session 36988 against 11 arifOS wrapper calls in one session. Birth-fix (+ token model + alias collapse) approved; full fix deferred to Phase B.
1. Same 11 tools → does the `decision_thresholds` block now differ per tool OR get referenced rather than copied?
2. Same wrapper for `arif_judge` → does one payload still contain two conflicting verdict fields?
3. Identity: does `actor_verified` stay constant from `arif_init` through `arif_seal`?
4. Orphan check: any unregistered inner tool fired today?

If yes/yes/yes/no, the birth-fix isn't enough — escalate.

## Provenance

First applied 2026-07-09 in AAA session 36988 against 11 arifOS wrapper calls in one session. Birth-fix (+ token model + alias collapse) approved; full fix deferred to Phase B.
