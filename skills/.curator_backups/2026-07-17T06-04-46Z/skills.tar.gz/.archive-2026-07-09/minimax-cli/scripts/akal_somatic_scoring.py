#!/usr/bin/env python3
"""
AKAL Somatic Scoring v1 — Audio quality evaluation for generated music.
Three checks: PULSE (temporal), SOUL (spectral), FLOW (entropy).
Uses ffmpeg only (no librosa dependency). Returns JSON.

Usage: python3 akal_somatic_scoring.py <audio.mp3> [audio2.mp3 ...]
"""

import subprocess
import json
import sys
import os

MANIFOLD = {
    "region": "Minangkabau", "genre": "Inang",
    "tempo_range_bpm": [85, 120],
    "loudness_range_lufs": [-18, -8],
    "lra_range": [3, 8],
    "max_true_peak_dbtp": 1.0,
}

def get_audio_info(path):
    cmd = ["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", path]
    r = subprocess.run(cmd, capture_output=True, text=True)
    d = json.loads(r.stdout)
    fmt = d["format"]; s = d["streams"][0]
    return {
        "duration": float(fmt.get("duration", 0)),
        "bitrate_kbps": int(fmt.get("bit_rate", 0)) // 1000,
        "sample_rate": int(s.get("sample_rate", 0)),
    }

def get_loudness(path):
    cmd = ["ffmpeg", "-i", path, "-af", "loudnorm=print_format=json", "-f", "null", "/dev/null"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    start = r.stderr.rfind("{"); end = r.stderr.rfind("}") + 1
    if start >= 0 and end > start:
        j = json.loads(r.stderr[start:end])
        return {
            "integrated_lufs": float(j.get("input_i", -100)),
            "true_peak_dbtp": float(j.get("input_tp", -100)),
            "lra": float(j.get("input_lra", 0)),
        }
    return None

def get_volume_stats(path):
    cmd = ["ffmpeg", "-i", path, "-af", "volumedetect", "-f", "null", "/dev/null"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    result = {}
    for line in r.stderr.split("\n"):
        if "max_volume" in line:
            try: result["max_volume_db"] = float(line.split("max_volume:")[1].strip().replace(" dB", ""))
            except: pass
        if "mean_volume" in line:
            try: result["mean_volume_db"] = float(line.split("mean_volume:")[1].strip().replace(" dB", ""))
            except: pass
    return result

def score_pulse(info, loudness):
    duration = info["duration"]
    lra = loudness["lra"] if loudness else 5.0
    dur_score = 1.0 if 60 <= duration <= 240 else 0.7 if 30 <= duration <= 300 else 0.3
    lra_score = 1.0 if 3 <= lra <= 8 else 0.7 if 2 <= lra <= 12 else 0.4
    pulse = 0.4 * dur_score + 0.6 * lra_score
    return {"score": round(pulse, 3), "duration_sec": round(duration, 1), "lra_db": round(lra, 2),
            "verdict": "PASS" if pulse >= 0.6 else "HOLD"}

def score_soul(loudness, manifold):
    if not loudness: return {"score": 0.5, "verdict": "SABAR", "reason": "no data"}
    lufs = loudness["integrated_lufs"]; lra = loudness["lra"]; tp = loudness["true_peak_dbtp"]
    lo, hi = manifold["loudness_range_lufs"]
    lufs_s = 1.0 if lo <= lufs <= hi else 0.6 if lo-5 <= lufs <= hi+5 else 0.3
    tp_s = 1.0 if tp <= manifold["max_true_peak_dbtp"] else 0.5 if tp <= 3.0 else 0.2
    lo_l, hi_l = manifold["lra_range"]
    lra_s = 1.0 if lo_l <= lra <= hi_l else 0.6 if lo_l-2 <= lra <= hi_l+3 else 0.3
    soul = 0.4*lufs_s + 0.3*tp_s + 0.3*lra_s
    return {"score": round(soul, 3), "lufs": round(lufs, 2), "peak": round(tp, 2), "lra": round(lra, 2),
            "verdict": "PASS" if soul >= 0.6 else "HOLD" if soul >= 0.4 else "SABAR"}

def score_flow(loudness, vol_stats):
    if not loudness: return {"score": 0.5, "verdict": "SABAR"}
    lra = loudness["lra"]; mean_vol = vol_stats.get("mean_volume_db", -20); max_vol = vol_stats.get("max_volume_db", 0)
    sterility = 0.4 if lra < 2 else 0.2 if lra < 3 else 0.0
    chaos = 0.4 if lra > 15 else 0.2 if lra > 12 else 0.0
    dr = abs(max_vol - mean_vol) if mean_vol != 0 else 0
    dr_s = 1.0 if 5 <= dr <= 20 else 0.7 if 3 <= dr <= 25 else 0.4
    flow = max(0.0, min(1.0, dr_s - sterility - chaos))
    return {"score": round(flow, 3), "dynamic_range_db": round(dr, 2),
            "verdict": "PASS" if flow >= 0.5 else "HOLD" if flow >= 0.3 else "SABAR"}

def analyze(path):
    info = get_audio_info(path)
    loudness = get_loudness(path)
    vol_stats = get_volume_stats(path)
    pulse = score_pulse(info, loudness)
    soul = score_soul(loudness, MANIFOLD)
    flow = score_flow(loudness, vol_stats)
    somatic = 0.3*pulse["score"] + 0.4*soul["score"] + 0.3*flow["score"]
    return {
        "file": os.path.basename(path), "info": info,
        "pulse": pulse, "soul": soul, "flow": flow,
        "somatic_score": round(somatic, 3),
        "verdict": "SEAL" if somatic >= 0.7 else "SABAR" if somatic >= 0.5 else "HOLD"
    }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 akal_somatic_scoring.py <audio.mp3> [...]")
        sys.exit(1)
    results = []
    for path in sys.argv[1:]:
        if not os.path.exists(path): print(f"  Not found: {path}"); continue
        r = analyze(path); results.append(r)
        print(f"\n  {r['file']}  ({r['info']['duration']:.1f}s)")
        print(f"    PULSE:  {r['pulse']['score']:.3f} ({r['pulse']['verdict']})")
        print(f"    SOUL:   {r['soul']['score']:.3f} ({r['soul']['verdict']})")
        print(f"    FLOW:   {r['flow']['score']:.3f} ({r['flow']['verdict']})")
        print(f"    SOMATIC: {r['somatic_score']:.3f} → {r['verdict']}")
    if len(results) > 1:
        print(f"\n  {'File':<30} {'PULSE':>6} {'SOUL':>6} {'FLOW':>6} {'SOM':>6} {'V':>6}")
        print(f"  {'─'*60}")
        for r in results:
            print(f"  {r['file']:<30} {r['pulse']['score']:>6.3f} {r['soul']['score']:>6.3f} {r['flow']['score']:>6.3f} {r['somatic_score']:>6.3f} {r['verdict']:>6}")
    print(json.dumps(results, indent=2))
