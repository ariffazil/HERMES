"""
Civic Intelligence PDF Generator — Jinja2 Template Engine
Usage: python3 generate_briefing.py content.json output.pdf

content.json structure:
{
  "title": "...",
  "subtitle": "...",
  "date": "...",
  "confidence": 72,
  "executive_summary": "...",
  "headline_quote": "...",
  "sections": [
    {
      "title": "Section Title",
      "number": "I",
      "subsections": [
        {
          "title": "Subsection",
          "level": 2,
          "content": "Paragraph text...",
          "tables": [...],
          "callouts": [...],
          "lists": [...]
        }
      ]
    }
  ],
  "thermometer": [...],
  "scar_map": [...],
  "reflection": {...},
  "appendices": [...],
  "glossary": [...]
}
"""
import sys
import json
from jinja2 import Template
from weasyprint import HTML

TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
  @page {
    size: A4;
    margin: 2cm 2.2cm;
    @top-left { content: "{{ title }} — {{ date }}"; font-size: 7pt; color: #8b949e; font-family: 'Helvetica', sans-serif; }
    @top-right { content: "arifOS Federation"; font-size: 7pt; color: #f0a500; font-family: 'Helvetica', sans-serif; font-weight: bold; }
    @bottom-center { content: "Page " counter(page) " of " counter(pages); font-size: 7pt; color: #8b949e; font-family: 'Helvetica', sans-serif; }
  }
  @page :first { @top-left { content: ""; } @top-right { content: ""; } }
  body { background: #0d1117; color: #e6edf3; font-family: 'Helvetica', 'DejaVu Sans', sans-serif; font-size: 10pt; line-height: 1.55; }
  a { color: #58a6ff; }
  .cover { text-align: center; padding-top: 120px; page-break-after: always; }
  .cover h1 { font-size: 28pt; color: #f0a500; margin-bottom: 8px; letter-spacing: 1px; }
  .cover h2 { font-size: 16pt; color: #ffa657; font-weight: normal; margin-bottom: 40px; }
  .cover .meta { font-size: 9pt; color: #8b949e; margin-top: 60px; line-height: 1.8; }
  .cover .meta strong { color: #e6edf3; }
  .cover .divider { width: 200px; height: 2px; background: #f0a500; margin: 30px auto; }
  .cover .tagline { font-size: 11pt; color: #ffa657; font-style: italic; margin-top: 40px; }
  h1 { color: #f0a500; font-size: 18pt; border-bottom: 2px solid #f0a500; padding-bottom: 6px; margin-top: 30px; page-break-after: avoid; }
  h2 { color: #ffa657; font-size: 14pt; margin-top: 22px; page-break-after: avoid; }
  h3 { color: #3fb950; font-size: 11pt; margin-top: 16px; page-break-after: avoid; }
  h4 { color: #58a6ff; font-size: 10pt; margin-top: 12px; }
  .signal-box { background: #161b22; border-left: 4px solid #f0a500; padding: 12px 16px; margin: 14px 0; border-radius: 0 6px 6px 0; }
  .signal-box.red { border-left-color: #f85149; }
  .signal-box.green { border-left-color: #3fb950; }
  .signal-box.amber { border-left-color: #ffa657; }
  .signal-box.blue { border-left-color: #58a6ff; }
  .signal-box strong { color: #f0a500; }
  .signal-box.red strong { color: #f85149; }
  .signal-box.green strong { color: #3fb950; }
  .exec-callout { background: #1a1f28; border: 2px solid #f0a500; padding: 20px 24px; margin: 20px 0; border-radius: 8px; }
  .exec-callout .headline { font-size: 14pt; color: #f0a500; font-weight: bold; margin-bottom: 10px; }
  .exec-callout .sub { color: #ffa657; font-size: 9pt; }
  .key-insight { background: #0d1f0d; border: 1px solid #3fb950; padding: 16px 20px; margin: 16px 0; border-radius: 6px; }
  .key-insight .label { color: #3fb950; font-size: 8pt; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; }
  .warning-box { background: #1f0d0d; border: 1px solid #f85149; padding: 16px 20px; margin: 16px 0; border-radius: 6px; }
  .warning-box .label { color: #f85149; font-size: 8pt; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; }
  table { width: 100%; border-collapse: collapse; margin: 14px 0; font-size: 9pt; }
  th { background: #1a2332; color: #f0a500; padding: 8px 10px; text-align: left; font-weight: bold; border-bottom: 2px solid #f0a500; }
  td { padding: 7px 10px; border-bottom: 1px solid #21262d; }
  tr:nth-child(even) td { background: #161b22; }
  tr:nth-child(odd) td { background: #0d1117; }
  .reading-critical { color: #f85149; font-weight: bold; }
  .reading-warning { color: #ffa657; font-weight: bold; }
  .reading-good { color: #3fb950; font-weight: bold; }
  .reading-info { color: #58a6ff; font-weight: bold; }
  blockquote { background: #161b22; border-left: 3px solid #ffa657; padding: 12px 16px; margin: 14px 0; font-style: italic; color: #ffa657; border-radius: 0 6px 6px 0; }
  ul, ol { margin: 8px 0; padding-left: 24px; }
  li { margin: 4px 0; }
  li strong { color: #ffa657; }
  hr { border: none; border-top: 1px solid #30363d; margin: 24px 0; }
  .summary-strip { background: #161b22; padding: 14px 18px; margin: 16px 0; border-radius: 6px; border: 1px solid #30363d; }
  .summary-strip .item { display: flex; justify-content: space-between; padding: 4px 0; border-bottom: 1px solid #21262d; }
  .summary-strip .item:last-child { border-bottom: none; }
  .summary-strip .item .label { color: #8b949e; }
  .summary-strip .item .value { font-weight: bold; }
  .tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 8pt; font-weight: bold; margin-right: 4px; }
  .tag-obs { background: #0d2818; color: #3fb950; }
  .tag-der { background: #1a1a0d; color: #ffa657; }
  .tag-int { background: #1a0d1a; color: #bc8cff; }
  .tag-spec { background: #1a0d0d; color: #f85149; }
  .page-break { page-break-before: always; }
  .footer-note { text-align: center; font-size: 8pt; color: #8b949e; margin-top: 40px; padding-top: 16px; border-top: 1px solid #30363d; }
</style>
</head>
<body>

<!-- COVER -->
<div class="cover">
  <h1>{{ title }}</h1>
  <div class="divider"></div>
  <h2>{{ subtitle }}</h2>
  {% if headline_quote %}
  <div class="tagline">"{{ headline_quote }}"</div>
  {% endif %}
  <div class="meta">
    <strong>Prepared by:</strong> {{ preparer | default("arifOS Federation | Hermes SOUL Layer") }}<br>
    <strong>Mode:</strong> {{ mode | default("Critique · Refinement · Synthesis | Auditor-Architect") }}<br>
    <strong>Epistemic Band:</strong> {{ epistemic_band | default("OBS / DER / INT (Tier 2–3)") }}<br>
    <strong>Confidence:</strong> {{ confidence | default(70) }} / 100<br>
    <strong>Classification:</strong> {{ classification | default("Civic Intelligence — Internal Use") }}
  </div>
</div>

<!-- EXECUTIVE SUMMARY -->
{% if executive_summary %}
<div class="exec-callout">
  <div class="headline">EXECUTIVE SUMMARY</div>
  {{ executive_summary }}
</div>
{% endif %}

<!-- SECTIONS -->
{% for section in sections %}
<div class="{% if section.page_break %}page-break{% endif %}">
  <h1><span style="color:#f0a500;font-weight:bold;margin-right:6px">{{ section.number }}</span> {{ section.title }}</h1>

  {% for sub in section.subsections %}
    {% if sub.level == 2 %}
      <h2>{{ sub.title }}</h2>
    {% elif sub.level == 3 %}
      <h3>{{ sub.title }}</h3>
    {% elif sub.level == 4 %}
      <h4>{{ sub.title }}</h4>
    {% endif %}

    {% if sub.content %}
    <p>{{ sub.content }}</p>
    {% endif %}

    {% for callout in sub.callouts %}
      {% if callout.type == "exec" %}
      <div class="exec-callout">
        <div class="headline">{{ callout.title }}</div>
        {{ callout.body }}
        {% if callout.sub %}<div class="sub">{{ callout.sub }}</div>{% endif %}
      </div>
      {% elif callout.type == "insight" %}
      <div class="key-insight">
        <div class="label">{{ callout.title }}</div>
        {{ callout.body }}
      </div>
      {% elif callout.type == "warning" %}
      <div class="warning-box">
        <div class="label">{{ callout.title }}</div>
        {{ callout.body }}
      </div>
      {% elif callout.type == "signal" %}
      <div class="signal-box {{ callout.color | default('') }}">
        {% if callout.title %}<strong>{{ callout.title }}</strong> {% endif %}{{ callout.body }}
      </div>
      {% endif %}
    {% endfor %}

    {% for table in sub.tables %}
    <table>
      <tr>{% for col in table.columns %}<th>{{ col }}</th>{% endfor %}</tr>
      {% for row in table.rows %}
      <tr>{% for cell in row %}<td>{{ cell }}</td>{% endfor %}</tr>
      {% endfor %}
    </table>
    {% endfor %}

    {% if sub.list %}
    <ul>
      {% for item in sub.list %}
      <li>{{ item }}</li>
      {% endfor %}
    </ul>
    {% endif %}

    {% if sub.blockquote %}
    <blockquote>{{ sub.blockquote }}</blockquote>
    {% endif %}
  {% endfor %}
</div>
{% endfor %}

<!-- CIVIC THERMOMETER -->
{% if thermometer %}
<div class="page-break"></div>
<h1>Civic Thermometer</h1>
<table>
  <tr><th>Dimension</th><th>Reading</th><th>Driver</th><th>Assessment</th></tr>
  {% for item in thermometer %}
  <tr>
    <td>{{ item.dimension }}</td>
    <td class="reading-{{ item.color | default('info') }}">{{ item.reading }}</td>
    <td>{{ item.driver }}</td>
    <td>{{ item.assessment }}</td>
  </tr>
  {% endfor %}
</table>
{% endif %}

<!-- SCAR MAP -->
{% if scar_map %}
<h2>Scar Metabolism Map</h2>
<table>
  <tr><th>Scar</th><th>Status</th><th>Action Required</th></tr>
  {% for scar in scar_map %}
  <tr>
    <td>{{ scar.name }}</td>
    <td class="reading-{{ scar.color | default('warning') }}">{{ scar.status }}</td>
    <td>{{ scar.action }}</td>
  </tr>
  {% endfor %}
</table>
{% endif %}

<!-- REFLECTION -->
{% if reflection %}
<div class="page-break"></div>
<h1>Daily Reflection Pulse</h1>

{% if reflection.feeling %}
<h2>Feeling</h2>
<p>{{ reflection.feeling }}</p>
{% endif %}

{% if reflection.facts %}
<h2>Fact</h2>
<div class="summary-strip">
  {% for fact in reflection.facts %}
  <div class="item">
    <span class="label">{{ fact.label }}</span>
    <span class="value reading-{{ fact.color | default('info') }}">{{ fact.value }}</span>
  </div>
  {% endfor %}
</div>
{% endif %}

{% if reflection.law %}
<h2>Law / Principle</h2>
<div class="signal-box">
  {{ reflection.law }}
</div>
{% endif %}
{% endif %}

<!-- APPENDICES -->
{% if appendices %}
<div class="page-break"></div>
<h1>Appendices</h1>
{% for app in appendices %}
<h2>{{ app.title }}</h2>
{% if app.content %}
<p>{{ app.content }}</p>
{% endif %}
{% for table in app.tables %}
<table>
  <tr>{% for col in table.columns %}<th>{{ col }}</th>{% endfor %}</tr>
  {% for row in table.rows %}
  <tr>{% for cell in row %}<td>{{ cell }}</td>{% endfor %}</tr>
  {% endfor %}
</table>
{% endfor %}
{% endfor %}
{% endif %}

<!-- GLOSSARY -->
{% if glossary %}
<h2>Glossary</h2>
<table>
  <tr><th>Term</th><th>Meaning</th></tr>
  {% for term in glossary %}
  <tr><td>{{ term.term }}</td><td>{{ term.meaning }}</td></tr>
  {% endfor %}
</table>
{% endif %}

<!-- FOOTER -->
<div class="footer-note">
  <strong>DITEMPA BUKAN DIBERI</strong><br>
  {{ disclaimer | default("This document is a consolidated intelligence synthesis. Epistemic witness-tier (OBS/DER/INT). No execution proposed.") }}<br>
  {{ preparer | default("arifOS Federation | Hermes SOUL Layer") }} | {{ date }}
</div>

</body>
</html>"""


def generate_pdf(content: dict, output_path: str):
    """Generate a civic intelligence PDF from structured content."""
    template = Template(TEMPLATE)
    html_content = template.render(**content)
    HTML(string=html_content).write_pdf(output_path)
    return output_path


def load_and_generate(input_json: str, output_pdf: str):
    """Load content from JSON file and generate PDF."""
    with open(input_json) as f:
        content = json.load(f)
    return generate_pdf(content, output_pdf)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 generate_briefing.py content.json output.pdf")
        sys.exit(1)
    result = load_and_generate(sys.argv[1], sys.argv[2])
    print(f"Generated: {result}")
